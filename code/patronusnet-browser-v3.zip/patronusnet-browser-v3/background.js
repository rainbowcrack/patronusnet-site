// PatronusNet v3 - Background Service Worker

// ── Schedule enforcement ──────────────────────────────────────────────────────
function checkSchedule(data) {
  const days  = data.patronus_sched_days;
  const start = data.patronus_sched_start;
  const end   = data.patronus_sched_end;

  // If no schedule configured, don't force anything
  if (!days || !start || !end) return;

  const now   = new Date();
  const wday  = now.getDay();
  const hhmm  = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const startM = sh * 60 + sm;
  const endM   = eh * 60 + em;

  const shouldBeActive = days.includes(wday) && hhmm >= startM && hhmm <= endM;
  chrome.storage.local.set({ patronus_enabled: shouldBeActive });
}

// Check schedule every minute
chrome.alarms.create('scheduleCheck', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'scheduleCheck') {
    chrome.storage.local.get([
      'patronus_sched_days', 'patronus_sched_start', 'patronus_sched_end'
    ], checkSchedule);
  }
});

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'CHECK_PAGE') {
    chrome.storage.local.get([
      'patronus_domains',
      'patronus_tags',
      'patronus_enabled',
      'patronus_password'
    ], (data) => {
      sendResponse({
        domains: data.patronus_domains || [],
        tags:    data.patronus_tags    || [],
        enabled: data.patronus_enabled !== false,
        password: data.patronus_password || ''
      });
    });
    return true;
  }

  if (message.type === 'LOG_BLOCK') {
    chrome.storage.local.get(['patronus_log'], (data) => {
      const log = data.patronus_log || [];
      log.unshift({
        url:       message.url,
        reason:    message.reason,
        matched:   message.matched,
        title:     message.title,
        timestamp: new Date().toISOString()
      });
      chrome.storage.local.set({ patronus_log: log.slice(0, 200) }); // bumped to 200
    });
    return true;
  }

  if (message.type === 'SAVE_SETTINGS') {
    chrome.storage.local.set(message.settings, () => sendResponse({ ok: true }));
    return true;
  }
});
