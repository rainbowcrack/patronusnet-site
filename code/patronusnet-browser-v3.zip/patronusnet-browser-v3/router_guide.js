// PatronusNet - Router Guide Injector
// Injected directly into 192.168.0.1 (and similar gateway IPs)
// Shows visual overlays, pulsing highlights and tooltip callouts on real router fields

(function () {
  if (window.__pnRouterGuide) return;
  window.__pnRouterGuide = true;

  // ── State ─────────────────────────────────────────────────────────────────
  let currentStep = 0;
  let overlays    = [];
  let tooltips    = [];
  let minimized   = false;

  // ── Step definitions ───────────────────────────────────────────────────────
  // Each step defines:
  //   title, desc, color
  //   targets: array of { selector, label, sublabel, placement, color }
  //   tabTarget: highlight a nav tab instead
  const STEPS = [
    {
      title: 'Bem-vindo ao guia PatronusNet',
      desc:  'Vou te guiar pelo painel do roteador para configurar o DNS de proteção parental. Clique em Próximo para começar.',
      color: 'orange',
      targets: []
    },
    {
      title: '① Digite o nome de usuário',
      desc:  'Encontre o campo "User Name" e digite: admin',
      color: 'orange',
      targets: [
        {
          selectors: [
            'input[name="loginUsername"]',
            'input[name="username"]',
            'input[id*="user" i]',
            'input[name*="user" i]',
            'input[type="text"]:not([type="password"])',
            'td:contains("User Name") + td input',
          ],
          label:    'USUÁRIO',
          sublabel: 'Digite: admin',
          icon:     '👤',
          placement: 'right',
          color:    'orange'
        }
      ]
    },
    {
      title: '② Digite a senha',
      desc:  'Encontre o campo "Password" e digite a senha. Padrão: password',
      color: 'orange',
      targets: [
        {
          selectors: [
            'input[type="password"]',
            'input[name="loginPassword"]',
            'input[name*="pass" i]',
            'input[id*="pass" i]',
          ],
          label:    'SENHA',
          sublabel: 'Padrão: password',
          icon:     '🔑',
          placement: 'right',
          color:    'orange'
        }
      ]
    },
    {
      title: '③ Clique em Apply / Login',
      desc:  'Clique no botão para entrar no painel de administração.',
      color: 'green',
      targets: [
        {
          selectors: [
            'input[type="submit"]',
            'button[type="submit"]',
            'input[value="Apply"]',
            'input[value="Login"]',
            'button:contains("Apply")',
            'input[value*="login" i]',
            'input[value*="apply" i]',
          ],
          label:    'ENTRAR',
          sublabel: 'Clique aqui',
          icon:     '✅',
          placement: 'top',
          color:    'green'
        }
      ]
    },
    {
      title: '④ Clique na aba HSD',
      desc:  'Após o login, clique na aba "HSD" no menu superior. É onde ficam as configurações de DNS.',
      color: 'blue',
      targets: [
        {
          selectors: [
            'a:contains("HSD")',
            'td:contains("HSD") a',
            'li:contains("HSD")',
            'div:contains("HSD") a',
            'a[href*="hsd" i]',
            'td.tabsel a',
            'td.tab a',
          ],
          label:    'ABA HSD',
          sublabel: 'Clique aqui',
          icon:     '🌐',
          placement: 'bottom',
          color:    'blue'
        }
      ]
    },
    {
      title: '⑤ Localize as configurações de DNS',
      desc:  'Role a página e procure os campos "Primary DNS" e "Secondary DNS". Eles ficam na seção WAN / DNS Settings.',
      color: 'blue',
      targets: [
        {
          selectors: [
            'input[name*="dns1" i]',
            'input[name*="primarydns" i]',
            'input[name*="dns_1" i]',
            'input[id*="dns1" i]',
            'input[id*="primary" i]',
            'td:contains("Primary DNS") + td input',
            'td:contains("DNS Server 1") + td input',
          ],
          label:    'DNS PRIMÁRIO',
          sublabel: 'Ex: 1.1.1.3',
          icon:     '1️⃣',
          placement: 'right',
          color:    'blue'
        },
        {
          selectors: [
            'input[name*="dns2" i]',
            'input[name*="secondarydns" i]',
            'input[name*="dns_2" i]',
            'input[id*="dns2" i]',
            'input[id*="secondary" i]',
            'td:contains("Secondary DNS") + td input',
            'td:contains("DNS Server 2") + td input',
          ],
          label:    'DNS SECUNDÁRIO',
          sublabel: 'Ex: 1.0.0.3',
          icon:     '2️⃣',
          placement: 'right',
          color:    'blue'
        }
      ]
    },
    {
      title: '⑥ Preencha com o DNS de proteção',
      desc:  'Digite os endereços DNS recomendados. Sugestão: Cloudflare Family (1.1.1.3 / 1.0.0.3) bloqueia conteúdo adulto e malware.',
      color: 'green',
      targets: [
        {
          selectors: [
            'input[name*="dns1" i]',
            'input[name*="primarydns" i]',
            'input[id*="dns1" i]',
            'td:contains("Primary DNS") + td input',
          ],
          label:    'DNS PRIMÁRIO',
          sublabel: 'Digite: 1.1.1.3',
          icon:     '🛡️',
          placement: 'right',
          color:    'green'
        },
        {
          selectors: [
            'input[name*="dns2" i]',
            'input[name*="secondarydns" i]',
            'input[id*="dns2" i]',
            'td:contains("Secondary DNS") + td input',
          ],
          label:    'DNS SECUNDÁRIO',
          sublabel: 'Digite: 1.0.0.3',
          icon:     '🛡️',
          placement: 'right',
          color:    'green'
        }
      ]
    },
    {
      title: '⑦ Salve clicando em Apply',
      desc:  'Após preencher o DNS, clique em Apply para salvar. O roteador pode reiniciar brevemente.',
      color: 'green',
      targets: [
        {
          selectors: [
            'input[type="submit"]',
            'input[value="Apply"]',
            'button[type="submit"]',
            'input[value*="apply" i]',
            'input[value*="save" i]',
          ],
          label:    'SALVAR',
          sublabel: 'Clique em Apply',
          icon:     '💾',
          placement: 'top',
          color:    'green'
        }
      ]
    },
    {
      title: '🎉 DNS configurado com sucesso!',
      desc:  'Todos os dispositivos da sua rede agora estão protegidos pelo DNS parental. Combine com o PatronusNet para proteção total!',
      color: 'green',
      targets: []
    }
  ];

  // ── DOM helpers ────────────────────────────────────────────────────────────

  // querySelector that also supports :contains() pseudo-selector
  function findElement(selectors) {
    for (const sel of selectors) {
      try {
        if (sel.includes(':contains(')) {
          const match = sel.match(/^(.*):contains\("(.+?)"\)(.*)$/);
          if (match) {
            const [, before, text, after] = match;
            const base = before || '*';
            const candidates = document.querySelectorAll(base || '*');
            for (const el of candidates) {
              if (el.textContent.trim().includes(text)) {
                if (after) {
                  const found = el.querySelector(after.replace(/^[ >+~]+/, ''));
                  if (found) return found;
                } else {
                  return el;
                }
              }
            }
          }
        } else {
          const el = document.querySelector(sel);
          if (el) return el;
        }
      } catch (e) { /* skip bad selector */ }
    }
    return null;
  }

  function getRect(el) {
    const r = el.getBoundingClientRect();
    return {
      top:    r.top  + window.scrollY,
      left:   r.left + window.scrollX,
      width:  r.width,
      height: r.height,
      bottom: r.top  + window.scrollY + r.height,
      right:  r.left + window.scrollX + r.width,
    };
  }

  // ── Clear overlays ─────────────────────────────────────────────────────────
  function clearOverlays() {
    overlays.forEach(el => el.remove());
    tooltips.forEach(el => el.remove());
    overlays = [];
    tooltips = [];
  }

  // ── Create highlight box around element ───────────────────────────────────
  function createHighlight(el, color) {
    const rect = getRect(el);
    const div  = document.createElement('div');
    div.className = `pn-field-overlay ${color}`;
    div.style.cssText = `
      top:    ${rect.top  - 4}px;
      left:   ${rect.left - 4}px;
      width:  ${rect.width  + 8}px;
      height: ${rect.height + 8}px;
    `;
    document.body.appendChild(div);
    overlays.push(div);
    return rect;
  }

  // ── Create tooltip callout ─────────────────────────────────────────────────
  function createTooltip(rect, target) {
    const { label, sublabel, icon, placement, color } = target;
    const tip = document.createElement('div');
    tip.className = `pn-tooltip ${color}`;

    tip.innerHTML = `
      <div class="pn-tooltip-label ${color}">${icon ? `<span class="pn-tooltip-icon">${icon}</span>` : ''}${label}</div>
      <div class="pn-tooltip-text">${sublabel}</div>
    `;

    // Position based on placement
    let top, left;
    const PAD = 14;

    switch (placement) {
      case 'right':
        top  = rect.top + rect.height / 2 - 30;
        left = rect.right + PAD;
        break;
      case 'left':
        top  = rect.top + rect.height / 2 - 30;
        left = rect.left - 200 - PAD;
        break;
      case 'top':
        top  = rect.top - 70 - PAD;
        left = rect.left + rect.width / 2 - 100;
        break;
      case 'bottom':
      default:
        top  = rect.bottom + PAD;
        left = rect.left + rect.width / 2 - 100;
        break;
    }

    // Clamp to viewport
    const vw = document.documentElement.clientWidth;
    if (left + 220 > vw) left = vw - 230;
    if (left < 8)        left = 8;

    tip.style.cssText = `top:${top}px; left:${left}px;`;
    document.body.appendChild(tip);
    tooltips.push(tip);

    // Scroll element into view
    const domEl = findElement(target.selectors);
    if (domEl) domEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  // ── Render current step overlays ──────────────────────────────────────────
  function renderOverlays() {
    clearOverlays();
    const step = STEPS[currentStep];
    if (!step || !step.targets.length) return;

    step.targets.forEach(target => {
      const el = findElement(target.selectors);
      if (!el) return;
      const rect = createHighlight(el, target.color);
      createTooltip(rect, target);
    });
  }

  // ── Build panel HTML ───────────────────────────────────────────────────────
  function buildPanel() {
    const panel = document.createElement('div');
    panel.id = 'pn-guide-panel';
    panel.innerHTML = `
      <div id="pn-guide-header">
        <div id="pn-guide-logo">
          <span>🛡️</span>
          <div>
            <strong>PatronusNet</strong>
            <small>Guia de configuração</small>
          </div>
        </div>
        <button id="pn-minimize-btn" title="Minimizar">−</button>
      </div>
      <div id="pn-guide-body">
        <div id="pn-step-indicator"></div>
        <div id="pn-step-num"></div>
        <div id="pn-step-title"></div>
        <div id="pn-step-desc"></div>
        <div id="pn-guide-actions">
          <button class="pn-nav-btn" id="pn-prev">← Anterior</button>
          <button class="pn-nav-btn primary" id="pn-next">Próximo →</button>
        </div>
      </div>
    `;
    document.body.appendChild(panel);

    // FAB for when minimized
    const fab = document.createElement('button');
    fab.id = 'pn-mini-fab';
    fab.textContent = '🛡️';
    fab.title = 'Abrir guia PatronusNet';
    document.body.appendChild(fab);

    // Events
    document.getElementById('pn-minimize-btn').addEventListener('click', toggleMinimize);
    fab.addEventListener('click', toggleMinimize);
    document.getElementById('pn-prev').addEventListener('click', () => go(-1));
    document.getElementById('pn-next').addEventListener('click', () => go(1));

    updatePanel();
  }

  // ── Update panel content ──────────────────────────────────────────────────
  function updatePanel() {
    const step    = STEPS[currentStep];
    const total   = STEPS.length;
    const isFirst = currentStep === 0;
    const isLast  = currentStep === total - 1;

    // Progress dots
    document.getElementById('pn-step-indicator').innerHTML =
      STEPS.map((_, i) =>
        `<div class="pn-step-dot ${i < currentStep ? 'done' : i === currentStep ? 'active' : ''}"></div>`
      ).join('');

    document.getElementById('pn-step-num').textContent   = `Passo ${currentStep + 1} de ${total}`;
    document.getElementById('pn-step-title').textContent = step.title;
    document.getElementById('pn-step-desc').textContent  = step.desc;

    const prevBtn = document.getElementById('pn-prev');
    const nextBtn = document.getElementById('pn-next');

    prevBtn.disabled    = isFirst;
    nextBtn.textContent = isLast ? '✓ Concluir' : 'Próximo →';
    nextBtn.style.background = isLast
      ? 'linear-gradient(135deg,#3B6D11,#27500A)'
      : '';

    renderOverlays();
  }

  // ── Navigate ──────────────────────────────────────────────────────────────
  function go(dir) {
    const next = currentStep + dir;
    if (next < 0 || next >= STEPS.length) return;
    currentStep = next;
    updatePanel();
  }

  // ── Minimize / restore ─────────────────────────────────────────────────────
  function toggleMinimize() {
    minimized = !minimized;
    const panel = document.getElementById('pn-guide-panel');
    const fab   = document.getElementById('pn-mini-fab');

    if (minimized) {
      panel.style.display = 'none';
      fab.style.display   = 'flex';
      clearOverlays();
    } else {
      panel.style.display = '';
      fab.style.display   = 'none';
      renderOverlays();
    }
  }

  // ── Re-render on page changes (SPA / form submits) ─────────────────────────
  let reRenderTimeout;
  const observer = new MutationObserver(() => {
    clearTimeout(reRenderTimeout);
    reRenderTimeout = setTimeout(() => {
      if (!minimized) renderOverlays();
    }, 600);
  });

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    buildPanel();
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
