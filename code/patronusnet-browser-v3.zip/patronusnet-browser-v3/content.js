// PatronusNet v2 - Content Script

(function () {
  if (window.__patronusRunning) return;
  window.__patronusRunning = true;

  let blocked = false;

  // ── helpers ──────────────────────────────────────────────────────────────
  function currentDomain() {
    return location.hostname.replace(/^www\./, '').toLowerCase();
  }

  function getPageText() {
    let text = document.title + ' ' + location.href + ' ';
    const metas = document.querySelectorAll('meta[name="keywords"],meta[name="description"],meta[property]');
    metas.forEach(m => { text += ' ' + (m.getAttribute('content') || ''); });
    if (document.body) text += ' ' + document.body.innerText;
    return text.toLowerCase();
  }

  function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  // ── main check ───────────────────────────────────────────────────────────
  function check() {
    if (blocked) return;

    chrome.runtime.sendMessage({ type: 'CHECK_PAGE' }, (res) => {
      if (chrome.runtime.lastError || !res || !res.enabled) return;

      const host = currentDomain();

      // 1. Domain block (exact or wildcard subdomain match)
      for (const d of res.domains) {
        const domain = (d.domain || d).toLowerCase().replace(/^www\./, '');
        if (host === domain || host.endsWith('.' + domain)) {
          blocked = true;
          blockPage('domain', domain, res.password);
          logBlock('domain', domain);
          return;
        }
      }

      // 2. Tag / content block
      if (res.tags.length === 0) return;
      const pageText = getPageText();

      for (const t of res.tags) {
        const tag = (t.tag || t).toLowerCase();
        if (!tag) continue;
        const inUrl  = location.href.toLowerCase().includes(tag);
        const inPage = new RegExp(`\\b${esc(tag)}\\b`, 'i').test(pageText);
        if (inUrl || inPage) {
          blocked = true;
          blockPage('tag', tag, res.password);
          logBlock('tag', tag);
          return;
        }
      }
    });
  }

  function logBlock(reason, matched) {
    chrome.runtime.sendMessage({
      type:    'LOG_BLOCK',
      url:     location.href,
      reason,
      matched,
      title:   document.title
    });
  }

  // ── block overlay ─────────────────────────────────────────────────────────
  function blockPage(reason, matched, savedPassword) {
    document.documentElement.style.overflow = 'hidden';

    const reasonText = reason === 'domain'
      ? `Domínio bloqueado: <strong>${matched}</strong>`
      : `Conteúdo detectado: <strong>"${matched}"</strong>`;

    const overlay = document.createElement('div');
    overlay.id = 'pn-overlay';
    overlay.innerHTML = `
      <div class="pn-bg"></div>
      <div class="pn-card">
        <div class="pn-icon">🛡️</div>
        <h1 class="pn-brand">PatronusNet</h1>
        <p class="pn-sub">Acesso Bloqueado</p>
        <div class="pn-reason">${reasonText}</div>
        <p class="pn-url">${location.href.length > 65 ? location.href.slice(0,65)+'…' : location.href}</p>
        ${savedPassword ? `
          <div class="pn-pass-wrap">
            <p class="pn-pass-hint">Insira a senha parental para continuar:</p>
            <div class="pn-row">
              <input id="pn-input" type="password" placeholder="Senha…" autocomplete="off"/>
              <button id="pn-btn">Entrar</button>
            </div>
            <p id="pn-err" style="display:none">❌ Senha incorreta.</p>
          </div>` : `<p class="pn-pass-hint" style="margin-top:16px;opacity:.6;">Nenhuma senha configurada.</p>`}
        <button class="pn-back" onclick="history.back()">← Voltar</button>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      #pn-overlay{position:fixed!important;inset:0!important;z-index:2147483647!important;
        display:flex!important;align-items:center!important;justify-content:center!important;
        font-family:'Segoe UI',system-ui,sans-serif!important;}
      .pn-bg{position:absolute!important;inset:0!important;
        background:linear-gradient(135deg,#0f0c29,#302b63,#24243e)!important;opacity:.97!important;}
      .pn-card{position:relative!important;background:rgba(255,255,255,.05)!important;
        backdrop-filter:blur(20px)!important;border:1px solid rgba(255,255,255,.12)!important;
        border-radius:24px!important;padding:44px 40px!important;max-width:460px!important;
        width:92vw!important;text-align:center!important;color:#fff!important;
        box-shadow:0 25px 70px rgba(0,0,0,.5)!important;
        animation:pnIn .45s cubic-bezier(.34,1.56,.64,1)!important;}
      @keyframes pnIn{from{transform:translateY(-36px) scale(.9);opacity:0}to{transform:none;opacity:1}}
      .pn-icon{font-size:52px!important;margin-bottom:10px!important;
        filter:drop-shadow(0 0 18px rgba(249,115,22,.55))!important;}
      .pn-brand{font-size:26px!important;font-weight:800!important;margin:0 0 4px!important;
        background:linear-gradient(135deg,#f97316,#fb923c)!important;
        -webkit-background-clip:text!important;-webkit-text-fill-color:transparent!important;
        background-clip:text!important;}
      .pn-sub{font-size:14px!important;color:rgba(255,255,255,.6)!important;margin:0 0 22px!important;}
      .pn-reason{background:rgba(249,115,22,.13)!important;border:1px solid rgba(249,115,22,.28)!important;
        border-radius:12px!important;padding:11px 18px!important;font-size:14px!important;
        color:rgba(255,255,255,.85)!important;margin-bottom:10px!important;}
      .pn-reason strong{color:#fb923c!important;}
      .pn-url{font-size:11px!important;color:rgba(255,255,255,.3)!important;
        margin:0 0 22px!important;word-break:break-all!important;}
      .pn-pass-hint{font-size:13px!important;color:rgba(255,255,255,.65)!important;margin-bottom:12px!important;}
      .pn-row{display:flex!important;gap:8px!important;}
      #pn-input{flex:1!important;background:rgba(255,255,255,.1)!important;
        border:1px solid rgba(255,255,255,.18)!important;border-radius:10px!important;
        padding:10px 14px!important;color:#fff!important;font-size:14px!important;outline:none!important;}
      #pn-input:focus{border-color:#f97316!important;}
      #pn-input::placeholder{color:rgba(255,255,255,.3)!important;}
      #pn-btn{background:linear-gradient(135deg,#f97316,#ea580c)!important;color:#fff!important;
        border:none!important;border-radius:10px!important;padding:10px 20px!important;
        font-size:14px!important;font-weight:700!important;cursor:pointer!important;}
      #pn-err{font-size:12px!important;color:#f87171!important;margin-top:8px!important;}
      .pn-pass-wrap{margin-bottom:20px!important;}
      .pn-back{margin-top:10px!important;background:transparent!important;
        border:1px solid rgba(255,255,255,.18)!important;color:rgba(255,255,255,.55)!important;
        border-radius:10px!important;padding:8px 20px!important;font-size:13px!important;
        cursor:pointer!important;}
      .pn-back:hover{background:rgba(255,255,255,.07)!important;color:#fff!important;}
    `;

    document.head.appendChild(style);
    document.body.appendChild(overlay);

    if (savedPassword) {
      const input = document.getElementById('pn-input');
      const btn   = document.getElementById('pn-btn');
      const err   = document.getElementById('pn-err');

      function tryUnlock() {
        if (input.value === savedPassword) {
          overlay.remove(); style.remove();
          document.documentElement.style.overflow = '';
          blocked = false;
        } else {
          err.style.display = 'block';
          input.value = '';
          input.focus();
        }
      }

      btn.addEventListener('click', tryUnlock);
      input.addEventListener('keydown', e => { if (e.key === 'Enter') tryUnlock(); });
    }
  }

  // ── run ───────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', check);
  } else {
    check();
  }

  // Re-check on SPA navigation
  let spaCooldown;
  const obs = new MutationObserver(() => {
    clearTimeout(spaCooldown);
    spaCooldown = setTimeout(() => { if (!blocked) check(); }, 1200);
  });
  if (document.body) obs.observe(document.body, { childList: true, subtree: true });

})();
