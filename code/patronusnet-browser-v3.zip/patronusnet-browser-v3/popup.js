// PatronusNet v3 - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(
    ['patronus_domains', 'patronus_tags', 'patronus_enabled', 'patronus_log'],
    (d) => {
      const enabled = d.patronus_enabled !== false;
      const log = d.patronus_log || [];

      // Toggle
      const tog = document.getElementById('tog');
      tog.checked = enabled;

      // Status dot
      const dot = document.getElementById('statusDot');
      dot.className = 'status-dot' + (enabled ? '' : ' off');

      // Stats
      document.getElementById('dn').textContent = (d.patronus_domains || []).length;
      document.getElementById('tn').textContent = (d.patronus_tags || []).length;
      document.getElementById('bn').textContent = log.length;

      // Today's blocks
      const today = new Date().toDateString();
      const todayBlocks = log.filter(e => new Date(e.timestamp).toDateString() === today);
      document.getElementById('todayCount').textContent = todayBlocks.length;
      const pct = Math.min(100, (todayBlocks.length / 10) * 100);
      document.getElementById('todayBar').style.width = pct + '%';

      // Last block
      const lastContent = document.getElementById('lastBlockContent');
      if (log.length > 0) {
        const last = log[0];
        const ago = timeAgo(new Date(last.timestamp));
        const icon = last.reason === 'domain' ? '🌐' : '🔍';
        lastContent.innerHTML = `
          <div class="lb-item">
            <span class="lb-icon">${icon}</span>
            <span class="lb-text">${last.matched || last.url}</span>
            <span class="lb-time">${ago}</span>
          </div>`;
      }
    }
  );

  // Toggle protection + update dot
  document.getElementById('tog').addEventListener('change', (e) => {
    chrome.storage.local.set({ patronus_enabled: e.target.checked });
    const dot = document.getElementById('statusDot');
    dot.className = 'status-dot' + (e.target.checked ? '' : ' off');
  });

  document.getElementById('cfg').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
    window.close();
  });

  document.getElementById('router').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') + '#router' });
    window.close();
  });

  document.getElementById('viewLog').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') + '#log' });
    window.close();
  });
});

function timeAgo(date) {
  const diff = Math.floor((Date.now() - date) / 1000);
  if (diff < 60) return 'agora';
  if (diff < 3600) return Math.floor(diff / 60) + 'min atrás';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h atrás';
  return Math.floor(diff / 86400) + 'd atrás';
}
