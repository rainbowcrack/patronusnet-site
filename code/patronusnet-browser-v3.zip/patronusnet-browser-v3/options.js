// PatronusNet v3 - Options Script
// NEW in v3: Dashboard, Schedule, CSV export

// ── Dashboard ────────────────────────────────────────────────────────────────
function initDashboard(data) {
  const log = data.patronus_log || [];
  const domains = data.patronus_domains || [];
  const tags = data.patronus_tags || [];

  const today = new Date().toDateString();
  const todayBlocks = log.filter(e => new Date(e.timestamp).toDateString() === today);

  // KPIs
  document.getElementById('kpi-total').textContent = log.length;
  document.getElementById('kpi-today-sub').textContent = todayBlocks.length + ' hoje';
  document.getElementById('kpi-domains').textContent = domains.length;
  document.getElementById('kpi-tags').textContent = tags.length;

  // Week blocks
  const now = new Date();
  const weekDays = Array.from({length:7}, (_, i) => {
    const d = new Date(now); d.setDate(now.getDate() - (6 - i));
    return d;
  });
  const weekCounts = weekDays.map(d =>
    log.filter(e => new Date(e.timestamp).toDateString() === d.toDateString()).length
  );
  document.getElementById('kpi-week').textContent = weekCounts.reduce((a,b) => a+b, 0);

  // Bar chart
  const maxVal = Math.max(...weekCounts, 1);
  const dayNames = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
  const chartEl = document.getElementById('weekChart');
  chartEl.innerHTML = weekDays.map((d, i) => {
    const pct = Math.round((weekCounts[i] / maxVal) * 100);
    return `<div class="bar-col">
      <div class="bar-body" style="height:${pct}%;" title="${weekCounts[i]} bloqueios"></div>
      <div class="bar-day">${dayNames[d.getDay()]}</div>
    </div>`;
  }).join('');

  // Top blocked
  const freq = {};
  log.forEach(e => {
    const key = e.matched || new URL(e.url||'http://x').hostname;
    freq[key] = (freq[key] || 0) + 1;
  });
  const sorted = Object.entries(freq).sort((a,b) => b[1]-a[1]).slice(0,5);
  const topEl = document.getElementById('topList');
  if (sorted.length === 0) {
    topEl.innerHTML = '<li style="font-size:13px;color:var(--tx-m);font-style:italic;">Nenhum bloqueio registrado.</li>';
  } else {
    topEl.innerHTML = sorted.map(([val, cnt], i) =>
      `<li class="top-item">
        <span class="top-rank">#${i+1}</span>
        <span class="top-val">${val}</span>
        <span class="top-cnt">${cnt}×</span>
      </li>`
    ).join('');
  }

  // Prot status
  const protEl = document.getElementById('protStatus');
  if (data.patronus_enabled !== false) {
    protEl.style.background = 'rgba(74,222,128,.12)';
    protEl.style.color = '#4ade80';
    protEl.textContent = 'Ativa';
  } else {
    protEl.style.background = 'rgba(239,68,68,.12)';
    protEl.style.color = '#f87171';
    protEl.textContent = 'Desativada';
  }
}

// ── Schedule ─────────────────────────────────────────────────────────────────
let schedDays = [0,1,2,3,4,5,6]; // all days default

function initSchedulePage(data) {
  schedDays = data.patronus_sched_days ?? [0,1,2,3,4,5,6];
  const start = data.patronus_sched_start || '07:00';
  const end   = data.patronus_sched_end   || '22:00';

  document.getElementById('schedStart').value = start;
  document.getElementById('schedEnd').value   = end;

  // Render day toggles
  document.querySelectorAll('.day-enabled').forEach(btn => {
    const d = parseInt(btn.dataset.d);
    btn.classList.toggle('on', schedDays.includes(d));
    btn.textContent = schedDays.includes(d) ? '✓' : '–';
    btn.addEventListener('click', () => {
      const idx = schedDays.indexOf(d);
      if (idx >= 0) schedDays.splice(idx, 1); else schedDays.push(d);
      btn.classList.toggle('on', schedDays.includes(d));
      btn.textContent = schedDays.includes(d) ? '✓' : '–';
      updateSchedStatus();
    });
  });

  updateSchedStatus();
}

function updateSchedStatus() {
  const now   = new Date();
  const wday  = now.getDay();
  const hhmm  = now.getHours() * 60 + now.getMinutes();
  const start = document.getElementById('schedStart').value || '07:00';
  const end   = document.getElementById('schedEnd').value   || '22:00';
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const startM = sh * 60 + sm;
  const endM   = eh * 60 + em;

  const dayActive = schedDays.includes(wday);
  const timeActive = hhmm >= startM && hhmm <= endM;
  const box = document.getElementById('schedStatusBox');

  if (dayActive && timeActive) {
    box.className = 'sched-status active';
    box.innerHTML = '<span>🟢</span> Proteção ATIVA agora — dentro do horário configurado.';
  } else if (!dayActive) {
    box.className = 'sched-status inactive';
    box.innerHTML = '<span>🔴</span> Hoje não é um dia de proteção ativada.';
  } else {
    box.className = 'sched-status inactive';
    box.innerHTML = `<span>🟡</span> Fora do horário. Próxima ativação às ${start}.`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const saveSchedBtn = document.getElementById('saveSchedBtn');
  if (saveSchedBtn) {
    saveSchedBtn.addEventListener('click', () => {
      const start = document.getElementById('schedStart').value;
      const end   = document.getElementById('schedEnd').value;
      chrome.storage.local.set({
        patronus_sched_days: schedDays,
        patronus_sched_start: start,
        patronus_sched_end: end,
      });
      toast('⏰ Agendamento salvo!');
      updateSchedStatus();
    });
  }
});

// ── CSV export ────────────────────────────────────────────────────────────────
function exportCSV(log) {
  const header = 'Timestamp,URL,Motivo,Correspondência,Título';
  const rows = log.map(e =>
    [e.timestamp, e.url, e.reason, e.matched, (e.title||'').replace(/,/g,' ')].join(',')
  );
  const csv = [header, ...rows].join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'patronusnet-historico.csv'; a.click();
  URL.revokeObjectURL(url);
  toast('✅ CSV exportado!');
}



let domains = [];
let tags    = [];

// ── Toast ────────────────────────────────────────────────────────────────────
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2600);
}

// ── Storage helpers ──────────────────────────────────────────────────────────
function saveDomains() { chrome.storage.local.set({ patronus_domains: domains }); }
function saveTags()    { chrome.storage.local.set({ patronus_tags: tags }); }

// ── Navigation ───────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    document.getElementById('page-' + item.dataset.page).classList.add('active');
    if (item.dataset.page === 'log') renderLog();
    if (item.dataset.page === 'router') initRouterPage();
    if (item.dataset.page === 'schedule') updateSchedStatus();
    if (item.dataset.page === 'dashboard') {
      chrome.storage.local.get(['patronus_log','patronus_domains','patronus_tags','patronus_enabled'], initDashboard);
    }
  });
});

// CSV export btn
document.addEventListener('DOMContentLoaded', () => {
  const csvBtn = document.getElementById('exportCsvBtn');
  if (csvBtn) {
    csvBtn.addEventListener('click', () => {
      chrome.storage.local.get(['patronus_log'], d => exportCSV(d.patronus_log || []));
    });
  }
});

// ── Render domains ────────────────────────────────────────────────────────────
function renderDomains() {
  document.getElementById('domCnt').textContent = domains.length;
  const box = document.getElementById('domChips');
  if (!domains.length) {
    box.innerHTML = '<span class="no-items">Nenhum domínio bloqueado.</span>';
    return;
  }
  box.innerHTML = domains.map((d, i) => {
    const val = d.domain || d;
    return `<div class="chip chip-domain">${val}
      <span class="chip-rm" data-type="domain" data-i="${i}">×</span></div>`;
  }).join('');
  box.querySelectorAll('.chip-rm[data-type=domain]').forEach(btn => {
    btn.addEventListener('click', () => {
      domains.splice(+btn.dataset.i, 1);
      saveDomains(); renderDomains();
      toast('Domínio removido.');
    });
  });
}

// ── Render tags ───────────────────────────────────────────────────────────────
function renderTags() {
  document.getElementById('tagCnt').textContent = tags.length;
  const box = document.getElementById('tagChips');
  if (!tags.length) {
    box.innerHTML = '<span class="no-items">Nenhuma tag adicionada.</span>';
    return;
  }
  box.innerHTML = tags.map((t, i) => {
    const val = t.tag || t;
    return `<div class="chip chip-tag">${val}
      <span class="chip-rm" data-type="tag" data-i="${i}">×</span></div>`;
  }).join('');
  box.querySelectorAll('.chip-rm[data-type=tag]').forEach(btn => {
    btn.addEventListener('click', () => {
      tags.splice(+btn.dataset.i, 1);
      saveTags(); renderTags();
      toast('Tag removida.');
    });
  });
}

// ── Add domain ────────────────────────────────────────────────────────────────
function addDomain(raw) {
  let val = raw.trim().toLowerCase()
    .replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0];
  if (!val) return;
  if (domains.some(d => (d.domain||d) === val)) { toast('⚠️ Já existe!'); return; }
  domains.push({ domain: val });
  saveDomains(); renderDomains();
  toast(`✅ "${val}" bloqueado!`);
}

document.getElementById('addDomBtn').addEventListener('click', () => {
  const inp = document.getElementById('domInput');
  addDomain(inp.value); inp.value = ''; inp.focus();
});
document.getElementById('domInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('addDomBtn').click();
});
document.querySelectorAll('#domPresets .preset').forEach(b =>
  b.addEventListener('click', () => addDomain(b.dataset.dom))
);
document.getElementById('clearDoms').addEventListener('click', () => {
  if (!confirm('Remover todos os domínios bloqueados?')) return;
  domains = []; saveDomains(); renderDomains(); toast('🗑️ Domínios removidos.');
});

// ── Add tag ───────────────────────────────────────────────────────────────────
function addTag(raw) {
  const val = raw.trim().toLowerCase();
  if (!val) return;
  if (tags.some(t => (t.tag||t) === val)) { toast('⚠️ Já existe!'); return; }
  tags.push({ tag: val });
  saveTags(); renderTags();
  toast(`✅ Tag "${val}" adicionada!`);
}

document.getElementById('addTagBtn').addEventListener('click', () => {
  const inp = document.getElementById('tagInput');
  addTag(inp.value); inp.value = ''; inp.focus();
});
document.getElementById('tagInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('addTagBtn').click();
});
document.querySelectorAll('#tagPresets .preset').forEach(b =>
  b.addEventListener('click', () => addTag(b.dataset.tag))
);
document.getElementById('clearTags').addEventListener('click', () => {
  if (!confirm('Remover todas as tags?')) return;
  tags = []; saveTags(); renderTags(); toast('🗑️ Tags removidas.');
});

// ── Settings ──────────────────────────────────────────────────────────────────
const togEnabled = document.getElementById('togEnabled');
const togUrl     = document.getElementById('togUrl');
const togContent = document.getElementById('togContent');

togEnabled.addEventListener('change', () => {
  chrome.storage.local.set({ patronus_enabled: togEnabled.checked });
  toast(togEnabled.checked ? '🛡️ Proteção ativada.' : '⚠️ Proteção desativada.');
});
togUrl.addEventListener('change', () =>
  chrome.storage.local.set({ patronus_check_url: togUrl.checked }));
togContent.addEventListener('change', () =>
  chrome.storage.local.set({ patronus_check_content: togContent.checked }));

// Password
const pw1 = document.getElementById('pw1');
const pw2 = document.getElementById('pw2');
document.getElementById('eyeBtn').addEventListener('click', () => {
  pw1.type = pw1.type === 'text' ? 'password' : 'text';
  document.getElementById('eyeBtn').textContent = pw1.type === 'text' ? '🙈' : '👁️';
});
document.getElementById('savePwBtn').addEventListener('click', () => {
  const msg = document.getElementById('pwMsg');
  if (!pw1.value) {
    chrome.storage.local.set({ patronus_password: '' });
    msg.style.display = 'block'; msg.style.color = '#fb923c';
    msg.textContent = '🔓 Senha removida.';
    pw1.value = pw2.value = ''; toast('Senha removida.'); return;
  }
  if (pw1.value !== pw2.value) {
    msg.style.display = 'block'; msg.style.color = '#f87171';
    msg.textContent = '❌ Senhas não coincidem.'; return;
  }
  chrome.storage.local.set({ patronus_password: pw1.value }, () => {
    msg.style.display = 'block'; msg.style.color = '#4ade80';
    msg.textContent = '✅ Senha salva!';
    pw1.value = pw2.value = ''; toast('🔑 Senha salva!');
  });
});

// Export
document.getElementById('exportBtn').addEventListener('click', () => {
  chrome.storage.local.get(null, data => {
    const blob = new Blob([JSON.stringify({
      patronus_domains: data.patronus_domains || [],
      patronus_tags:    data.patronus_tags    || [],
      patronus_enabled: data.patronus_enabled,
      patronus_check_url: data.patronus_check_url,
      patronus_check_content: data.patronus_check_content,
      exported_at: new Date().toISOString()
    }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'patronusnet-backup.json';
    a.click();
    toast('📦 Exportado!');
  });
});

// Import
document.getElementById('importBtn').addEventListener('click', () =>
  document.getElementById('importFile').click());
document.getElementById('importFile').addEventListener('change', e => {
  const file = e.target.files[0]; if (!file) return;
  const r = new FileReader();
  r.onload = ev => {
    try {
      const d = JSON.parse(ev.target.result);
      const s = {};
      if (d.patronus_domains) { domains = d.patronus_domains; s.patronus_domains = domains; }
      if (d.patronus_tags)    { tags    = d.patronus_tags;    s.patronus_tags    = tags; }
      if (d.patronus_enabled !== undefined) s.patronus_enabled = d.patronus_enabled;
      if (d.patronus_check_url !== undefined) s.patronus_check_url = d.patronus_check_url;
      if (d.patronus_check_content !== undefined) s.patronus_check_content = d.patronus_check_content;
      chrome.storage.local.set(s, () => {
        loadAll(); toast(`✅ Backup importado!`);
      });
    } catch { toast('❌ Arquivo inválido.'); }
  };
  r.readAsText(file);
  e.target.value = '';
});

// Reset
document.getElementById('resetBtn').addEventListener('click', () => {
  if (!confirm('Apagar TUDO? (domínios, tags, senha, histórico)')) return;
  chrome.storage.local.clear(() => { domains=[]; tags=[]; loadAll(); toast('🗑️ Redefinido.'); });
});

// ── Log ───────────────────────────────────────────────────────────────────────
function renderLog() {
  chrome.storage.local.get(['patronus_log'], data => {
    const log  = data.patronus_log || [];
    const list = document.getElementById('logList');
    if (!log.length) {
      list.innerHTML = '<div class="empty">✅ Nenhum bloqueio registrado.</div>'; return;
    }
    list.innerHTML = log.map(e => {
      const d = new Date(e.timestamp);
      const t = d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
      const cls = e.reason === 'domain' ? 'domain-block' : '';
      const badgeCls = e.reason === 'domain' ? 'badge-domain' : 'badge-tag';
      const icon = e.reason === 'domain' ? '🌐' : '🏷️';
      return `<div class="log-item ${cls}">
        <div style="font-size:18px;margin-top:1px;">${icon}</div>
        <div class="log-body">
          <div class="log-ttl">${e.title || 'Sem título'}</div>
          <div class="log-url">${e.url}</div>
          <div class="log-meta">
            <span class="badge ${badgeCls}">${e.matched}</span>
            <span class="log-time">${t}</span>
          </div>
        </div>
      </div>`;
    }).join('');
  });
}

document.getElementById('clearLogBtn').addEventListener('click', () => {
  if (!confirm('Limpar histórico?')) return;
  chrome.storage.local.set({ patronus_log: [] }, () => { renderLog(); toast('🗑️ Histórico limpo.'); });
});

// ── Router Guide ──────────────────────────────────────────────────────────────
const DNS_LIST = [
  { name: 'CleanBrowsing Family', pri: '185.228.168.168', sec: '185.228.169.168', badges: ['family','safe'], desc: 'Bloqueia adulto, malware e phishing' },
  { name: 'OpenDNS FamilyShield', pri: '208.67.222.123',  sec: '208.67.220.123',  badges: ['family'],        desc: 'Proteção para famílias da Cisco' },
  { name: 'Cloudflare Family',    pri: '1.1.1.3',          sec: '1.0.0.3',          badges: ['fast','safe'],   desc: 'Ultra rápido + bloqueia malware/adulto' },
  { name: 'Google Safe',          pri: '8.8.8.8',          sec: '8.8.4.4',          badges: ['fast'],          desc: 'Confiável e rápido, sem filtro de conteúdo' },
];

const GUIDE_STEPS = [
  // ── PASSO 1: Abrir o painel ──────────────────────────────────────────────
  {
    title: '① Abra o painel do roteador',
    desc:  'Digite o IP do roteador na barra do navegador e pressione Enter. A tela de login do ARRIS vai aparecer.',
    renderMock() {
      return `
        <div class="mock-browser">
          <div class="mock-bar">
            <div class="mock-dot" style="background:#e74c3c"></div>
            <div class="mock-dot" style="background:#f39c12"></div>
            <div class="mock-dot" style="background:#2ecc71"></div>
            <div class="mock-url-box" id="mock-ip-url" style="color:#facc15;font-weight:700;">http://192.168.0.1</div>
            <div class="mock-warn">⚠ Não seguro</div>
          </div>
          <div class="arris-logo-row"><div class="arris-logo-txt">ARRIS</div></div>
          <div class="arris-body">
            <div class="mock-sec">Login</div>
            <div style="font-size:12px;color:var(--tx-m);margin-bottom:6px;">Tela de login do roteador ARRIS.</div>
          </div>
        </div>
        <div class="hint-box">
          Use o botão <strong style="color:var(--tx)">"Abrir painel do roteador"</strong> acima, ou cole manualmente
          <code>http://192.168.0.1</code> na barra de endereços e pressione <strong style="color:var(--tx)">Enter</strong>.
        </div>`;
    }
  },

  // ── PASSO 2: Login ───────────────────────────────────────────────────────
  {
    title: '② Digite usuário, senha e clique em Apply',
    desc:  'Preencha os campos de login e clique em Apply. Após entrar, você será redirecionado ao painel principal.',
    renderMock() {
      return `
        <div class="mock-browser">
          <div class="mock-bar">
            <div class="mock-dot" style="background:#e74c3c"></div>
            <div class="mock-dot" style="background:#f39c12"></div>
            <div class="mock-dot" style="background:#2ecc71"></div>
            <div class="mock-url-box">http://${routerIP}/</div>
          </div>
          <div class="arris-logo-row"><div class="arris-logo-txt">ARRIS</div></div>
          <div class="arris-body">
            <div class="mock-sec" style="color:#f97316;">Login</div>
            <div class="mock-form-row">
              <div class="mock-label">User Name</div>
              <div class="mock-input hi" style="
                color:#60a5fa;font-weight:700;
                border:1.5px solid #60a5fa;
                box-shadow:0 0 0 3px rgba(96,165,250,.18);
              ">admin</div>
            </div>
            <div class="mock-form-row">
              <div class="mock-label">Password</div>
              <div class="mock-input hi" style="
                letter-spacing:5px;
                border:1.5px solid #60a5fa;
                box-shadow:0 0 0 3px rgba(96,165,250,.18);
              ">••••••••</div>
            </div>
            <button class="mock-apply p" style="margin-top:10px;">Apply</button>
          </div>
        </div>
        <div class="hint-box">
          Credenciais padrão: <code>admin</code> / <code>password</code>.<br>
          Se não funcionar, verifique a etiqueta embaixo do roteador.<br>
          <strong style="color:#fde68a;">Após clicar em Apply →</strong> siga para o próximo passo.
        </div>`;
    }
  },

  // ── PASSO 3: Navegar para LAN Setup ─────────────────────────────────────
  {
    title: '③ Acesse a página LAN Setup',
    desc:  'Após o login, cole o endereço abaixo na barra do navegador e pressione Enter — ou clique em "LAN Setup" no menu do roteador.',
    renderMock() {
      return `
        <div class="mock-browser">
          <div class="mock-bar">
            <div class="mock-dot" style="background:#e74c3c"></div>
            <div class="mock-dot" style="background:#f39c12"></div>
            <div class="mock-dot" style="background:#2ecc71"></div>
            <div class="mock-url-box" style="
              color:#4ade80;font-weight:700;font-size:11px;
              background:rgba(74,222,128,.07);
              border:1px solid rgba(74,222,128,.25);
              border-radius:4px;padding:2px 8px;
            ">http://${routerIP}/?lan_settings</div>
          </div>
          <div class="arris-logo-row"><div class="arris-logo-txt">ARRIS</div></div>
          <div class="arris-topbar">
            <div class="arris-tab">Wireless</div>
            <div class="arris-tab">HSD</div>
            <!-- LAN Setup destacado com animação -->
            <div class="arris-tab" style="
              color:#fff !important;
              background:linear-gradient(135deg,#00c6ff,#0072ff);
              border-radius:6px;
              padding:4px 12px;
              font-weight:700;
              box-shadow:0 0 0 3px rgba(0,198,255,.35);
              animation:pn-tab-pulse 1.4s infinite;
              position:relative;
            ">LAN Setup ☚</div>
            <div class="arris-tab">Logout</div>
          </div>
          <div class="arris-body">
            <div style="font-size:12px;color:var(--tx-m);margin-top:6px;">
              Aguardando navegação para LAN Setup…
            </div>
          </div>
        </div>
        <style>
          @keyframes pn-tab-pulse {
            0%,100% { box-shadow:0 0 0 3px rgba(0,198,255,.35); }
            50%      { box-shadow:0 0 0 7px rgba(0,198,255,.0); }
          }
        </style>
        <div class="hint-box" style="border-left-color:#4ade80;background:rgba(74,222,128,.05);">
          <strong style="color:#4ade80;">Opção A</strong> — Cole na barra do navegador:<br>
          <code style="user-select:all;color:#fde68a;">http://${routerIP}/?lan_settings</code><br><br>
          <strong style="color:#4ade80;">Opção B</strong> — No painel do roteador, clique em
          <strong style="color:#fff;background:linear-gradient(135deg,#00c6ff,#0072ff);padding:1px 8px;border-radius:4px;">LAN Setup</strong>
          no menu superior (destaque azul acima).
        </div>`;
    }
  },

  // ── PASSO 4: Enable DNS Override ────────────────────────────────────────
  {
    title: '④ Marque "Enable DNS Override"',
    desc:  'Na página LAN Setup, localize e marque a caixa "Enable DNS Override". Isso habilita os campos de DNS manual.',
    renderMock() {
      return `
        <div class="mock-browser">
          <div class="mock-bar">
            <div class="mock-dot" style="background:#e74c3c"></div>
            <div class="mock-dot" style="background:#f39c12"></div>
            <div class="mock-dot" style="background:#2ecc71"></div>
            <div class="mock-url-box" style="color:#60a5fa;font-weight:600;font-size:11px;">
              http://${routerIP}/?lan_settings
            </div>
          </div>
          <div class="arris-logo-row"><div class="arris-logo-txt">ARRIS</div></div>
          <div class="arris-topbar">
            <div class="arris-tab">Wireless</div>
            <div class="arris-tab">HSD</div>
            <div class="arris-tab on" style="color:#38bdf8;">LAN Setup</div>
            <div class="arris-tab">Logout</div>
          </div>
          <div class="arris-body">
            <div class="mock-sec blue">LAN Setup</div>

            <div class="mock-form-row">
              <div class="mock-label" style="color:var(--tx-m);">IP Address</div>
              <div class="mock-input" style="color:var(--tx-m);opacity:.5;">192.168.0.1</div>
            </div>
            <div class="mock-form-row">
              <div class="mock-label" style="color:var(--tx-m);">Subnet Mask</div>
              <div class="mock-input" style="color:var(--tx-m);opacity:.5;">255.255.255.0</div>
            </div>

            <div style="border-top:1px solid rgba(255,255,255,.07);margin:10px 0;"></div>

            <!-- ENABLE DNS OVERRIDE — caixa vibrante -->
            <div style="
              border: 2px solid #facc15;
              border-radius: 9px;
              padding: 11px 13px;
              background: rgba(250,204,21,.09);
              box-shadow: 0 0 0 5px rgba(250,204,21,.13), 0 0 18px rgba(250,204,21,.12);
              animation: pn-glow-yellow 1.6s infinite;
              margin-bottom: 6px;
              display:flex; align-items:center; justify-content:space-between;
            ">
              <div style="font-size:13px;font-weight:800;color:#fef08a;letter-spacing:.3px;">
                Enable DNS Override
              </div>
              <!-- checkbox vazio = ainda não marcado -->
              <div style="
                width:20px;height:20px;border-radius:4px;
                border:2px solid #facc15;
                background:transparent;
                flex-shrink:0;
              "></div>
            </div>
            <div style="font-size:10px;color:#fde68a;margin-bottom:10px;padding-left:2px;animation:pn-glow-yellow 1.6s infinite;">
              ☝️ Marque esta caixa para liberar os campos de DNS abaixo
            </div>

            <div class="mock-form-row" style="opacity:.25;">
              <div class="mock-label">Primary DNS Server IP</div>
              <div class="mock-input">0.0.0.0</div>
            </div>
            <div class="mock-form-row" style="opacity:.25;">
              <div class="mock-label">Secondary DNS Server IP</div>
              <div class="mock-input">0.0.0.0</div>
            </div>
            <div class="mock-form-row" style="opacity:.25;">
              <div class="mock-label">Tertiary DNS Server IP</div>
              <div class="mock-input">0.0.0.0</div>
            </div>
          </div>
        </div>
        <style>
          @keyframes pn-glow-yellow {
            0%,100% { box-shadow:0 0 0 4px rgba(250,204,21,.15), 0 0 14px rgba(250,204,21,.1); }
            50%      { box-shadow:0 0 0 8px rgba(250,204,21,.0),  0 0 22px rgba(250,204,21,.22); }
          }
        </style>
        <div class="hint-box" style="border-left-color:#facc15;background:rgba(250,204,21,.05);">
          <strong style="color:#fde68a;">Enable DNS Override</strong> precisa estar marcado
          para que os campos de DNS fiquem editáveis. Sem essa opção ativa, o roteador
          ignora qualquer endereço digitado.
        </div>`;
    }
  },

  // ── PASSO 5: Preencher os 3 DNS ─────────────────────────────────────────
  {
    title: '⑤ Preencha os três campos de DNS e clique em Apply',
    desc:  'Com o DNS Override marcado, insira os endereços abaixo em cada campo e clique em Apply para salvar.',
    renderMock() {
      return `
        <div class="mock-browser">
          <div class="mock-bar">
            <div class="mock-dot" style="background:#e74c3c"></div>
            <div class="mock-dot" style="background:#f39c12"></div>
            <div class="mock-dot" style="background:#2ecc71"></div>
            <div class="mock-url-box" style="color:#60a5fa;font-weight:600;font-size:11px;">
              http://${routerIP}/?lan_settings
            </div>
          </div>
          <div class="arris-logo-row"><div class="arris-logo-txt">ARRIS</div></div>
          <div class="arris-topbar">
            <div class="arris-tab">Wireless</div>
            <div class="arris-tab">HSD</div>
            <div class="arris-tab on" style="color:#38bdf8;">LAN Setup</div>
            <div class="arris-tab">Logout</div>
          </div>
          <div class="arris-body">
            <div class="mock-sec blue">LAN Setup</div>

            <!-- Override = marcado/confirmado -->
            <div style="
              border:2px solid #00c6ff;border-radius:9px;padding:8px 13px;
              background:rgba(0,198,255,.08);margin-bottom:12px;
              display:flex;align-items:center;justify-content:space-between;
            ">
              <div style="font-size:13px;font-weight:700;color:#7dd3fc;">Enable DNS Override</div>
              <div style="
                width:20px;height:20px;border-radius:4px;
                background:linear-gradient(135deg,#00c6ff,#0072ff);
                display:flex;align-items:center;justify-content:center;
                font-size:13px;font-weight:900;color:#fff;flex-shrink:0;
              ">✓</div>
            </div>

            <!-- Primary DNS — destaque vibrante -->
            <div style="
              border:2px solid #00c6ff;border-radius:8px;padding:8px 12px;
              background:rgba(0,198,255,.07);
              box-shadow:0 0 0 3px rgba(0,198,255,.15);
              margin-bottom:8px;
            ">
              <div style="font-size:10px;color:#7dd3fc;font-weight:700;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px;">
                Primary DNS Server IP
              </div>
              <div style="font-family:monospace;font-size:16px;font-weight:800;color:#fff;letter-spacing:.5px;">
                181.213.132.8
              </div>
            </div>

            <!-- Secondary DNS — destaque vibrante -->
            <div style="
              border:2px solid #38bdf8;border-radius:8px;padding:8px 12px;
              background:rgba(56,189,248,.07);
              box-shadow:0 0 0 3px rgba(56,189,248,.13);
              margin-bottom:8px;
            ">
              <div style="font-size:10px;color:#7dd3fc;font-weight:700;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px;">
                Secondary DNS Server IP
              </div>
              <div style="font-family:monospace;font-size:16px;font-weight:800;color:#fff;letter-spacing:.5px;">
                181.213.132.9
              </div>
            </div>

            <!-- Tertiary DNS — destaque mais suave -->
            <div style="
              border:2px solid rgba(56,189,248,.5);border-radius:8px;padding:8px 12px;
              background:rgba(56,189,248,.04);
              margin-bottom:12px;
            ">
              <div style="font-size:10px;color:#7dd3fc;font-weight:700;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px;">
                Tertiary DNS Server IP
                <span style="color:var(--tx-m);font-weight:400;font-size:9px;">(opcional — mesmo do Secondary)</span>
              </div>
              <div style="font-family:monospace;font-size:16px;font-weight:800;color:#93c5fd;letter-spacing:.5px;">
                181.213.132.9
              </div>
            </div>

            <button class="mock-apply p" style="width:100%;font-size:14px;padding:10px;">Apply</button>
            <div style="margin-top:8px;font-size:11px;color:#4ade80;text-align:center;">
              ✓ Configurações de DNS salvas com sucesso!
            </div>
          </div>
        </div>
        <div class="hint-box" style="border-left-color:#3B6D11;background:rgba(74,222,128,.06);">
          Digite exatamente:<br>
          • <strong style="color:#fff;">Primary:</strong>
            <code style="color:#4ade80;">181.213.132.8</code><br>
          • <strong style="color:#fff;">Secondary:</strong>
            <code style="color:#4ade80;">181.213.132.9</code><br>
          • <strong style="color:#fff;">Tertiary:</strong>
            <code style="color:#93c5fd;">181.213.132.9</code>
            <span style="color:var(--tx-m);">(mesmo do Secondary como fallback)</span><br><br>
          Após preencher, clique em <strong style="color:#fff;">Apply</strong>.
          Todos os dispositivos da rede passarão a usar o DNS de proteção.
        </div>`;
    }
  }
];

let routerIP    = '192.168.0.1';
let guideStep   = 0;
let selectedDNS = DNS_LIST[0];

function detectRouterIP() {
  const display = document.getElementById('router-ip-display');
  const status  = document.getElementById('router-ip-status');
  const openBtn = document.getElementById('open-router-btn');
  if (!display) return;

  // Try common gateway IPs via fetch with short timeout
  const candidates = ['192.168.0.1','192.168.1.1','192.168.2.1','10.0.0.1','10.0.1.1'];
  display.textContent = 'Detectando...';
  status.textContent  = '';

  let found = false;
  let checked = 0;

  candidates.forEach(ip => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 1500);
    fetch(`http://${ip}`, { signal: ctrl.signal, mode: 'no-cors' })
      .then(() => {
        clearTimeout(t);
        if (!found) {
          found = true;
          routerIP = ip;
          display.textContent = ip;
          status.textContent  = '✓ Roteador encontrado';
          status.style.color  = '#4ade80';
          openBtn.style.display = 'inline-block';
          openBtn.onclick = () => window.open(`http://${ip}`, '_blank');
          const urlBox = document.getElementById('mock-ip-url');
          if (urlBox) urlBox.textContent = `http://${ip}`;
          renderGuideStep();
        }
      })
      .catch(() => {
        clearTimeout(t);
        checked++;
        if (checked === candidates.length && !found) {
          display.textContent = '192.168.0.1';
          status.textContent  = 'Não detectado — usando padrão';
          status.style.color  = 'var(--tx-m)';
          openBtn.style.display = 'inline-block';
          openBtn.onclick = () => window.open('http://192.168.0.1', '_blank');
        }
      });
  });
}

function renderGuideProg() {
  const el = document.getElementById('guide-prog');
  if (!el) return;
  el.innerHTML = GUIDE_STEPS.map((_, i) =>
    `<div class="prog-seg ${i <= guideStep ? 'done' : ''}"></div>`
  ).join('');
}

function renderGuideStep() {
  const stepEl   = document.getElementById('guide-step');
  const navEl    = document.getElementById('guide-nav');
  const counterEl= document.getElementById('step-counter');
  if (!stepEl) return;

  const s = GUIDE_STEPS[guideStep];
  const isLast = guideStep === GUIDE_STEPS.length - 1;

  counterEl.textContent = `Passo ${guideStep + 1} de ${GUIDE_STEPS.length}`;

  stepEl.innerHTML = `
    <div style="font-size:16px;font-weight:600;margin-bottom:8px;color:var(--tx);">${s.title}</div>
    <div style="font-size:13px;color:var(--tx-m);margin-bottom:14px;line-height:1.6;">${s.desc}</div>
    ${s.renderMock()}
  `;

  navEl.innerHTML = `
    <button class="g-btn" id="g-prev" ${guideStep === 0 ? 'disabled' : ''}>← Anterior</button>
    ${isLast
      ? `<button class="g-btn next" id="g-done">✓ Concluído</button>`
      : `<button class="g-btn next" id="g-next">Próximo →</button>`
    }
  `;

  renderGuideProg();

  document.getElementById('g-prev')?.addEventListener('click', () => { if (guideStep > 0) { guideStep--; renderGuideStep(); } });
  document.getElementById('g-next')?.addEventListener('click', () => { if (guideStep < GUIDE_STEPS.length - 1) { guideStep++; renderGuideStep(); } });
  document.getElementById('g-done')?.addEventListener('click', () => { toast('🎉 Roteador configurado com sucesso!'); });

  // Show DNS card on last 2 steps
  const dnsCard = document.getElementById('dns-card');
  if (dnsCard) dnsCard.style.display = guideStep >= 3 ? 'block' : 'none';
}

function renderDNSCards() {
  const el = document.getElementById('dns-list');
  if (!el) return;
  el.innerHTML = `<div class="dns-grid">${DNS_LIST.map((d, i) => `
    <div class="dns-card-item" style="cursor:pointer;border-color:${selectedDNS===d ? 'var(--or)' : 'var(--bdr)'};" data-dns="${i}">
      <div class="dns-name">${d.name}</div>
      <div class="dns-ips">
        ${d.pri} <button class="copy-dns" data-ip="${d.pri}">copiar</button><br>
        ${d.sec} <button class="copy-dns" data-ip="${d.sec}">copiar</button>
      </div>
      <div style="font-size:11px;color:var(--tx-m);margin-top:4px;">${d.desc}</div>
      <div style="margin-top:6px;">${d.badges.map(b => `<span class="dns-badge ${b}">${b === 'family' ? '👨‍👩‍👧 família' : b === 'fast' ? '⚡ rápido' : '🛡️ seguro'}</span>`).join(' ')}</div>
    </div>`).join('')}</div>`;

  el.querySelectorAll('.dns-card-item').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.classList.contains('copy-dns')) return;
      const i = parseInt(card.dataset.dns);
      selectedDNS = DNS_LIST[i];
      renderDNSCards();
      renderGuideStep();
    });
  });

  el.querySelectorAll('.copy-dns').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(btn.dataset.ip).then(() => {
        btn.textContent = '✓';
        setTimeout(() => { btn.textContent = 'copiar'; }, 1500);
      });
    });
  });
}

function initRouterPage() {
  guideStep = 0;
  detectRouterIP();
  renderGuideStep();
  renderDNSCards();
}

// ── Init ──────────────────────────────────────────────────────────────────────
function loadAll() {
  chrome.storage.local.get([
    'patronus_domains','patronus_tags',
    'patronus_enabled','patronus_check_url','patronus_check_content',
    'patronus_log','patronus_sched_days','patronus_sched_start','patronus_sched_end'
  ], data => {
    domains = data.patronus_domains || [];
    tags    = data.patronus_tags    || [];
    togEnabled.checked = data.patronus_enabled !== false;
    togUrl.checked     = data.patronus_check_url !== false;
    togContent.checked = data.patronus_check_content !== false;
    renderDomains();
    renderTags();

    // v3 additions
    initDashboard(data);
    initSchedulePage(data);
  });
}

loadAll();

// Handle hash navigation from popup
const hashPage = location.hash.replace('#','');
if (hashPage && document.querySelector(`[data-page="${hashPage}"]`)) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelector(`[data-page="${hashPage}"]`).classList.add('active');
  document.getElementById('page-' + hashPage).classList.add('active');
  if (hashPage === 'router') initRouterPage();
  if (hashPage === 'log') renderLog();
}
