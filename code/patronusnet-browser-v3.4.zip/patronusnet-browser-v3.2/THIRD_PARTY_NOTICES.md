# Componentes de terceiros

O pacote distribuído da PatronusNet incorpora os seguintes componentes:

- **Transformers.js 3.8.1**, Hugging Face, licença Apache-2.0.
  <https://github.com/huggingface/transformers.js>
- **ONNX Runtime Web 1.21.0**, Microsoft, licença MIT.
  <https://github.com/microsoft/onnxruntime>

O modelo padrão `Xenova/toxic-bert` não é incorporado ao pacote. Seus arquivos são
obtidos como dados na primeira utilização e armazenados no cache do navegador. A página
do modelo e sua licença devem ser consultadas antes de qualquer distribuição que passe a
incorporar os pesos diretamente.
