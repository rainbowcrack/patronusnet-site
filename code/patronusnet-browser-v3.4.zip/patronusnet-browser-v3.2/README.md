# PatronusNet Browser

Extensão Manifest V3 de controle parental e proteção contextual de conteúdo.

## Build reproduzível

Requisitos: Node.js e pnpm.

```powershell
pnpm install
pnpm build
pnpm check
```

O diretório `dist/` contém somente os arquivos que devem ser carregados como extensão
descompactada ou compactados para submissão à Chrome Web Store. O Transformers.js e o
ONNX Runtime são incorporados ao bundle, e os binários WASM são servidos localmente pela
própria extensão.

## Carregar no Chrome

1. Abra `chrome://extensions`.
2. Ative o **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação**.
4. Para desenvolvimento direto, selecione esta pasta raiz, que contém o `manifest.json`.
5. Para testar exatamente o pacote de publicação, execute `pnpm build` e selecione `dist/`.

Depois de alterar HTML, CSS ou JavaScript, clique em **Recarregar** no cartão da extensão.
Também recarregue as abas abertas para reinjetar os content scripts atualizados.

Os pesos do modelo de classificação podem ser baixados do Hugging Face Hub na primeira
utilização e ficam no cache local do navegador. Nenhum texto extraído das páginas é enviado
ao Hub.
