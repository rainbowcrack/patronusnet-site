// PatronusNet v3.4 - Background Service Worker

const AUTH_KEY = 'patronus_auth';
const LEGACY_PASSWORD_KEY = 'patronus_password';
const PBKDF2_ITERATIONS = 210000;
const DOMAIN_RULE_BASE = 10000;
const DOMAIN_RULE_LIMIT = 5000;
const SESSION_ALLOW_BASE = 1000000;
const UNLOCK_MINUTES = 10;
const BLOCK_LOG_LIMIT = 200;
const VISIT_LOG_LIMIT = 1000;
const pendingKey = tabId => `patronus_pending_${tabId}`;
const authFailures = new Map();
const recentVisits = new Map();

function bytesToBase64(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(value);
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

function constantTimeEqual(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let i = 0; i < left.length; i += 1) difference |= left[i] ^ right[i];
  return difference === 0;
}

async function derivePassword(password, salt, iterations = PBKDF2_ITERATIONS) {
  const material = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(password),
    'PBKDF2',
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits({
    name: 'PBKDF2',
    hash: 'SHA-256',
    salt,
    iterations
  }, material, 256);
  return new Uint8Array(bits);
}

async function createPasswordRecord(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derivePassword(password, salt);
  return {
    version: 2,
    algorithm: 'PBKDF2-SHA-256',
    iterations: PBKDF2_ITERATIONS,
    salt: bytesToBase64(salt),
    hash: bytesToBase64(hash)
  };
}

async function sha256Hex(value) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

async function verifyPassword(password) {
  const data = await chrome.storage.local.get([AUTH_KEY]);
  const record = data[AUTH_KEY];
  if (!record) return true;

  if (typeof record === 'string') {
    return constantTimeEqual(
      new TextEncoder().encode(await sha256Hex(password)),
      new TextEncoder().encode(record)
    );
  }

  if (record.version !== 2 || !record.salt || !record.hash) return false;
  const actual = await derivePassword(password, base64ToBytes(record.salt), record.iterations);
  return constantTimeEqual(actual, base64ToBytes(record.hash));
}

async function migrateLegacyPassword() {
  const data = await chrome.storage.local.get([AUTH_KEY, LEGACY_PASSWORD_KEY]);
  if (!data[LEGACY_PASSWORD_KEY]) return;
  if (!data[AUTH_KEY]) {
    await chrome.storage.local.set({ [AUTH_KEY]: await createPasswordRecord(data[LEGACY_PASSWORD_KEY]) });
  }
  await chrome.storage.local.remove(LEGACY_PASSWORD_KEY);
}

function normalizeDomain(entry) {
  const raw = String(entry?.domain ?? entry ?? '').trim().toLowerCase();
  const domain = raw.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0].split(':')[0];
  if (!domain || domain.length > 253) return null;
  if (!/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(domain)) return null;
  return domain;
}

function hostnameMatchesDomain(hostname, domain) {
  const host = String(hostname || '').toLowerCase().replace(/^www\./, '');
  return host === domain || host.endsWith(`.${domain}`);
}

async function appendBlockLog(entry) {
  const data = await chrome.storage.local.get(['patronus_log']);
  const log = data.patronus_log || [];
  log.unshift({
    url: entry.url || '',
    reason: entry.reason || 'tag',
    matched: entry.matched || '',
    title: entry.title || '',
    timestamp: entry.timestamp || new Date().toISOString()
  });
  await chrome.storage.local.set({ patronus_log: log.slice(0, BLOCK_LOG_LIMIT) });
}

async function appendVisitLog(entry, tabId) {
  if (!/^https?:/i.test(entry.url || '')) return;
  const dedupeKey = `${tabId ?? 'unknown'}:${entry.url}`;
  const previous = recentVisits.get(dedupeKey) || 0;
  if (Date.now() - previous < 5000) return;
  recentVisits.set(dedupeKey, Date.now());
  if (recentVisits.size > 250) {
    const cutoff = Date.now() - 60000;
    for (const [key, timestamp] of recentVisits) {
      if (timestamp < cutoff) recentVisits.delete(key);
    }
  }

  const data = await chrome.storage.local.get(['patronus_visit_log']);
  const visits = data.patronus_visit_log || [];
  visits.unshift({
    url: entry.url,
    title: entry.title || '',
    timestamp: entry.timestamp || new Date().toISOString()
  });
  await chrome.storage.local.set({ patronus_visit_log: visits.slice(0, VISIT_LOG_LIMIT) });
}

async function syncDomainRules() {
  const data = await chrome.storage.local.get([
    'patronus_domains', 'patronus_enabled', 'patronus_stealth_mode'
  ]);
  const domains = data.patronus_enabled === false
    ? []
    : [...new Set((data.patronus_domains || []).map(normalizeDomain).filter(Boolean))]
    .slice(0, DOMAIN_RULE_LIMIT);
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing
    .filter(rule => rule.id >= DOMAIN_RULE_BASE && rule.id < DOMAIN_RULE_BASE + DOMAIN_RULE_LIMIT)
    .map(rule => rule.id);
  const addRules = domains.map((domain, index) => ({
    id: DOMAIN_RULE_BASE + index,
    priority: 1,
    action: data.patronus_stealth_mode === true
      ? { type: 'block' }
      : { type: 'redirect', redirect: { extensionPath: '/blocked.html' } },
    condition: {
      urlFilter: `||${domain}^`,
      resourceTypes: ['main_frame']
    }
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
}

async function rememberNavigation(details) {
  if (details.frameId !== 0 || !/^https?:/i.test(details.url)) return;
  await chrome.storage.session.set({
    [pendingKey(details.tabId)]: {
      url: details.url,
      title: '',
      reason: 'domain',
      matched: normalizeDomain(new URL(details.url).hostname) || new URL(details.url).hostname,
      timestamp: Date.now()
    }
  });
}

async function recordStealthDomainAttempt(details) {
  if (details.frameId !== 0 || !/^https?:/i.test(details.url)) return;
  const data = await chrome.storage.local.get([
    'patronus_stealth_mode', 'patronus_enabled', 'patronus_domains'
  ]);
  if (data.patronus_stealth_mode !== true || data.patronus_enabled === false) return;

  const parsed = new URL(details.url);
  const blockedDomain = (data.patronus_domains || [])
    .map(normalizeDomain)
    .filter(Boolean)
    .find(domain => hostnameMatchesDomain(parsed.hostname, domain));
  if (!blockedDomain) return;

  const entry = {
    url: details.url,
    title: '',
    reason: 'domain',
    matched: blockedDomain,
    timestamp: new Date().toISOString()
  };
  await Promise.all([
    appendBlockLog(entry),
    appendVisitLog(entry, details.tabId)
  ]);
}

async function recordStealthVisit(details) {
  if (details.frameId !== 0 || !/^https?:/i.test(details.url)) return;
  const data = await chrome.storage.local.get(['patronus_stealth_mode']);
  if (data.patronus_stealth_mode !== true) return;
  let title = '';
  try {
    const tab = await chrome.tabs.get(details.tabId);
    title = tab.title || '';
  } catch {
    // A aba pode ter sido fechada antes do término do carregamento.
  }
  await appendVisitLog({
    url: details.url,
    title,
    timestamp: new Date().toISOString()
  }, details.tabId);
}

async function getBlockContext(tabId) {
  const data = await chrome.storage.session.get([pendingKey(tabId)]);
  return data[pendingKey(tabId)] || null;
}

async function setTemporaryGrant(tabId, context) {
  const expiresAt = Date.now() + UNLOCK_MINUTES * 60 * 1000;
  const grantsData = await chrome.storage.session.get(['patronus_unlock_grants']);
  const grants = grantsData.patronus_unlock_grants || {};
  grants[tabId] = { url: context.url, reason: context.reason, expiresAt };
  await chrome.storage.session.set({ patronus_unlock_grants: grants });

  if (context.reason === 'domain') {
    const domain = normalizeDomain(new URL(context.url).hostname);
    if (domain) {
      const ruleId = SESSION_ALLOW_BASE + tabId;
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [ruleId],
        addRules: [{
          id: ruleId,
          priority: 100,
          action: { type: 'allow' },
          condition: {
            urlFilter: `||${domain}^`,
            resourceTypes: ['main_frame'],
            tabIds: [tabId]
          }
        }]
      });
    }
  }

  chrome.alarms.create(`unlock:${tabId}`, { delayInMinutes: UNLOCK_MINUTES });
}

async function clearTemporaryGrant(tabId) {
  const grantsData = await chrome.storage.session.get(['patronus_unlock_grants']);
  const grants = grantsData.patronus_unlock_grants || {};
  delete grants[tabId];
  await chrome.storage.session.set({ patronus_unlock_grants: grants });
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [SESSION_ALLOW_BASE + tabId]
  }).catch(() => {});
}

async function hasTemporaryGrant(tabId, url) {
  if (tabId == null) return false;
  const data = await chrome.storage.session.get(['patronus_unlock_grants']);
  const grant = data.patronus_unlock_grants?.[tabId];
  if (!grant || grant.expiresAt <= Date.now()) {
    if (grant) await clearTemporaryGrant(tabId);
    return false;
  }
  try {
    return new URL(grant.url).hostname === new URL(url).hostname;
  } catch {
    return false;
  }
}

function passwordRateLimit(tabId) {
  const state = authFailures.get(tabId);
  if (!state?.lockedUntil || state.lockedUntil <= Date.now()) return 0;
  return Math.ceil((state.lockedUntil - Date.now()) / 1000);
}

function recordPasswordFailure(tabId) {
  const state = authFailures.get(tabId) || { count: 0, lockedUntil: 0 };
  state.count += 1;
  if (state.count >= 5) {
    state.count = 0;
    state.lockedUntil = Date.now() + 30000;
  }
  authFailures.set(tabId, state);
}

function checkSchedule(data) {
  const days = data.patronus_sched_days;
  const start = data.patronus_sched_start;
  const end = data.patronus_sched_end;
  if (!days || !start || !end) return;

  const now = new Date();
  const wday = now.getDay();
  const previousDay = (wday + 6) % 7;
  const hhmm = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const startM = sh * 60 + sm;
  const endM = eh * 60 + em;
  const shouldBeActive = startM <= endM
    ? days.includes(wday) && hhmm >= startM && hhmm <= endM
    : (days.includes(wday) && hhmm >= startM) || (days.includes(previousDay) && hhmm <= endM);
  chrome.storage.local.set({ patronus_enabled: shouldBeActive });
}

chrome.alarms.create('scheduleCheck', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'scheduleCheck') {
    chrome.storage.local.get([
      'patronus_sched_days', 'patronus_sched_start', 'patronus_sched_end'
    ], checkSchedule);
  } else if (alarm.name.startsWith('unlock:')) {
    clearTemporaryGrant(Number(alarm.name.slice('unlock:'.length)));
  }
});

chrome.webNavigation.onBeforeNavigate.addListener(details => {
  rememberNavigation(details).catch(error => console.warn('[PatronusNet] Falha ao registrar navegação:', error));
  recordStealthDomainAttempt(details).catch(error => console.warn('[PatronusNet] Falha ao registrar tentativa:', error));
});

chrome.webNavigation.onCompleted.addListener(details => {
  recordStealthVisit(details).catch(error => console.warn('[PatronusNet] Falha ao registrar visita:', error));
});

chrome.webNavigation.onHistoryStateUpdated.addListener(details => {
  recordStealthVisit(details).catch(error => console.warn('[PatronusNet] Falha ao registrar navegação interna:', error));
});

chrome.tabs.onRemoved.addListener(tabId => {
  clearTemporaryGrant(tabId).catch(() => {});
  chrome.storage.session.remove(pendingKey(tabId));
  authFailures.delete(tabId);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (
    changes.patronus_domains || changes.patronus_enabled || changes.patronus_stealth_mode
  )) {
    syncDomainRules().catch(error => console.error('[PatronusNet] Falha ao atualizar regras DNR:', error));
  }
});

chrome.runtime.onInstalled.addListener(() => {
  migrateLegacyPassword();
  chrome.storage.local.get(['patronus_stealth_mode']).then(data => {
    if (data.patronus_stealth_mode === undefined) {
      return chrome.storage.local.set({ patronus_stealth_mode: false });
    }
  });
  syncDomainRules();
});

migrateLegacyPassword().catch(error => console.error('[PatronusNet] Falha na migração da senha:', error));
syncDomainRules().catch(error => console.error('[PatronusNet] Falha ao inicializar DNR:', error));

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CHECK_PAGE') {
    Promise.all([
      chrome.storage.local.get([
        'patronus_tags', 'patronus_enabled', 'patronus_check_url',
        'patronus_check_content', 'patronus_stealth_mode'
      ]),
      hasTemporaryGrant(sender.tab?.id, sender.url || message.url || '')
    ]).then(([data, granted]) => sendResponse({
      tags: data.patronus_tags || [],
      enabled: data.patronus_enabled !== false && !granted,
      checkUrl: data.patronus_check_url !== false,
      checkContent: data.patronus_check_content !== false,
      stealthMode: data.patronus_stealth_mode === true
    }));
    return true;
  }

  if (message.type === 'BLOCK_CURRENT_PAGE') {
    const tabId = sender.tab?.id;
    if (tabId == null || !/^https?:/i.test(message.url || '')) return false;
    chrome.storage.session.set({
      [pendingKey(tabId)]: {
        url: message.url,
        title: message.title || '',
        reason: message.reason || 'tag',
        matched: message.matched || '',
        timestamp: Date.now()
      }
    }).then(() => chrome.tabs.update(tabId, { url: chrome.runtime.getURL('blocked.html') }));
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'STEALTH_BLOCK_CURRENT_PAGE') {
    const tabId = sender.tab?.id;
    if (tabId == null || !/^https?:/i.test(message.url || '')) return false;
    const context = {
      url: message.url,
      title: message.title || '',
      reason: message.reason || 'tag',
      matched: message.matched || '',
      timestamp: new Date().toISOString()
    };
    Promise.all([
      chrome.storage.session.set({ [pendingKey(tabId)]: context }),
      appendBlockLog(context),
      appendVisitLog(context, tabId)
    ]).then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === 'GET_BLOCK_CONTEXT') {
    const tabId = sender.tab?.id;
    Promise.all([getBlockContext(tabId), chrome.storage.local.get([AUTH_KEY])])
      .then(([context, auth]) => sendResponse({
        context,
        hasPassword: Boolean(auth[AUTH_KEY]),
        unlockMinutes: UNLOCK_MINUTES
      }));
    return true;
  }

  if (message.type === 'UNLOCK_BLOCKED_PAGE') {
    const tabId = sender.tab?.id;
    const retryAfter = passwordRateLimit(tabId);
    if (retryAfter > 0) {
      sendResponse({ ok: false, retryAfter });
      return true;
    }
    Promise.all([verifyPassword(message.password || ''), getBlockContext(tabId)])
      .then(async ([valid, context]) => {
        if (!valid || !context?.url) {
          recordPasswordFailure(tabId);
          sendResponse({ ok: false, retryAfter: passwordRateLimit(tabId) });
          return;
        }
        authFailures.delete(tabId);
        await setTemporaryGrant(tabId, context);
        await chrome.tabs.update(tabId, { url: context.url });
        sendResponse({ ok: true });
      })
      .catch(error => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message.type === 'VERIFY_PASSWORD') {
    const authKey = sender.tab?.id ?? sender.documentId ?? sender.url ?? 'extension-ui';
    const retryAfter = passwordRateLimit(authKey);
    if (retryAfter > 0) {
      sendResponse({ ok: false, retryAfter });
      return true;
    }
    verifyPassword(message.password || '').then(ok => {
      if (ok) authFailures.delete(authKey);
      else recordPasswordFailure(authKey);
      sendResponse({ ok, retryAfter: passwordRateLimit(authKey) });
    });
    return true;
  }

  if (message.type === 'GET_AUTH_STATUS') {
    chrome.storage.local.get([AUTH_KEY]).then(data => sendResponse({
      hasPassword: Boolean(data[AUTH_KEY])
    }));
    return true;
  }

  if (message.type === 'SET_PARENT_PASSWORD') {
    const password = String(message.password || '');
    if (password.length < 4) {
      sendResponse({ ok: false, error: 'A senha deve ter pelo menos 4 caracteres.' });
      return true;
    }
    createPasswordRecord(password)
      .then(record => chrome.storage.local.set({ [AUTH_KEY]: record }))
      .then(() => chrome.storage.local.remove(LEGACY_PASSWORD_KEY))
      .then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'REMOVE_PARENT_PASSWORD') {
    chrome.storage.local.remove([AUTH_KEY, LEGACY_PASSWORD_KEY]).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'LOG_BLOCK') {
    appendBlockLog({
      url: message.url,
      reason: message.reason,
      matched: message.matched,
      title: message.title
    });
    return true;
  }
});
