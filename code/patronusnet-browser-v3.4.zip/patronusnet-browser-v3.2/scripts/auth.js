async function verificarSenha(senha) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'VERIFY_PASSWORD', password: senha }, response => {
      resolve(!chrome.runtime.lastError && response?.ok === true);
    });
  });
}
