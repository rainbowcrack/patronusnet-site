import { env, pipeline } from '@huggingface/transformers';

// PatronusNet — Módulo de IA Local (Transformers.js / ONNX)
// ─────────────────────────────────────────────────────────────────────────
// Objetivo: bloqueio CONTEXTUAL (por elemento, não a página inteira) de
// discurso de ódio em fóruns (Reddit, Quora) e notícias sensíveis, usando
// um classificador semântico rodando 100% no navegador do usuário
// (nenhum texto é enviado para servidores externos — apenas o modelo em
// si é baixado uma vez do Hugging Face Hub e fica em cache local).
//
// Este arquivo é aditivo: não altera content.js, background.js nem o
// fluxo de bloqueio por domínio/tag já existente. Ele roda em paralelo.
//
// FLUXO (conforme solicitado):
//  1) Scraping leve do DOM (posts/comentários/parágrafos visíveis)
//  2) Pré-filtro por termos-gatilho (evita rodar o modelo em tudo)
//  3) Classificação semântica local via modelo Hugging Face (ONNX)
//  4) Se confidence > limiar → oculta o elemento + registra no histórico
// ─────────────────────────────────────────────────────────────────────────

(function () {
  if (window.__patronusAiRunning) return;
  window.__patronusAiRunning = true;

  // ── Config padrão (sobrescrita via chrome.storage.local) ────────────────
  const DEFAULTS = {
    patronus_ai_enabled: true,
    // Domínios-alvo padrão. O usuário pode adicionar outros (ex.: portais
    // de notícia) na tela de Configurações → "IA Local".
    patronus_ai_domains: [
      'reddit.com',
      'quora.com',
      'news.ycombinator.com'
    ],
    // Ativa também em qualquer página cujo <html lang> ou meta indique
    // artigo de notícia (heurística leve, sem custo de rede).
    patronus_ai_match_news_heuristic: true,
    // Modelo ONNX compatível com Transformers.js. Multilingue (cobre PT-BR)
    // e leve o suficiente para rodar no navegador via WASM.
    // Pode ser trocado na UI por qualquer modelo de text-classification
    // publicado no Hugging Face Hub com pesos ONNX (ou espelhado em
    // huggingface.co/Xenova).
    patronus_ai_model_id: 'Xenova/toxic-bert',
    patronus_ai_threshold: 0.75,
    // Pré-filtro leve (PT-BR) para não gastar CPU classificando tudo.
    // Só textos com match aqui chegam ao modelo.
    patronus_ai_prefilter_terms: [
      'idiota', 'imbecil', 'burro', 'burra', 'lixo', 'nojento', 'nojenta',
      'morra', 'morre', 'mata', 'matar', 'suicid', 'se mate', 'vadia',
      'vagabundo', 'vagabunda', 'racis', 'nazis', 'estuprador', 'estupro',
      'pedofil', 'terrorista', 'genocídio', 'odeio', 'ódio', 'inferioridade',
      'subumano', 'subumana', 'exterminar', 'merda', 'porra', 'desgraça',
      'crianca', 'menor de idade'
    ],
    patronus_ai_max_elements_per_scan: 40
  };

  let cfg = { ...DEFAULTS };
  let classifierPipeline = null;
  let classifierState = 'idle'; // idle | loading | ready | unavailable
  const processed = new WeakSet();
  const textCache = new Map();

  // ── Utilidades ───────────────────────────────────────────────────────────
  function currentDomain() {
    return location.hostname.replace(/^www\./, '').toLowerCase();
  }

  function isTargetDomain(domains) {
    const host = currentDomain();
    return domains.some(d => {
      const domain = d.toLowerCase().replace(/^www\./, '');
      return host === domain || host.endsWith('.' + domain);
    });
  }

  function looksLikeNewsArticle() {
    if (document.querySelector('meta[property="article:published_time"]')) return true;
    if (document.querySelector('script[type="application/ld+json"]')) {
      const nodes = document.querySelectorAll('script[type="application/ld+json"]');
      for (const n of nodes) {
        if (/"@type"\s*:\s*"(NewsArticle|Article)"/i.test(n.textContent || '')) return true;
      }
    }
    return false;
  }

  function passesPrefilter(text, terms) {
    if (!terms || terms.length === 0) return true; // pré-filtro desativado
    const lower = text.toLowerCase();
    return terms.some(t => t && lower.includes(t.toLowerCase()));
  }

  // Seletores genéricos de "unidades de conteúdo" — cobre Reddit, Quora e
  // páginas de notícia comuns sem depender de classes específicas frágeis.
  const CONTENT_SELECTORS = [
    '[data-testid*="comment"]',
    'shreddit-comment',
    'shreddit-post',
    '.Comment',
    '.q-box.spacing_log_area_page',
    'article p',
    '.article-body p',
    '.post p',
    'p'
  ];

  function collectCandidateElements(limit) {
    const seen = new Set();
    const out = [];
    for (const sel of CONTENT_SELECTORS) {
      let nodes;
      try { nodes = document.querySelectorAll(sel); } catch (e) { continue; }
      for (const el of nodes) {
        if (processed.has(el) || seen.has(el)) continue;
        const text = (el.innerText || el.textContent || '').trim();
        if (text.length < 25 || text.length > 2000) continue; // ruído / texto longo demais
        seen.add(el);
        out.push(el);
        if (out.length >= limit) return out;
      }
    }
    return out;
  }

  // ── Carregamento preguiçoso do Transformers.js (ONNX runtime em WASM) ───
  // Só é baixado se: (a) o módulo está ativo, (b) a página é alvo, e
  // (c) pelo menos um elemento passou no pré-filtro. Assim evitamos custo
  // de rede/CPU em navegação comum.
  async function ensureClassifier() {
    if (classifierState === 'ready') return classifierPipeline;
    if (classifierState === 'unavailable') return null;
    if (classifierState === 'loading') {
      // aguarda a instância em andamento
      while (classifierState === 'loading') await new Promise(r => setTimeout(r, 150));
      return classifierPipeline;
    }

    classifierState = 'loading';
    try {
      // A biblioteca e o ONNX Runtime são empacotados no bundle da extensão.
      // Somente os pesos do modelo podem ser obtidos remotamente como dados.
      env.allowLocalModels = false;
      env.allowRemoteModels = true;
      env.useBrowserCache = true; // cacheia o modelo (IndexedDB) após 1º download
      env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL('vendor/ort/');

      classifierPipeline = await pipeline('text-classification', cfg.patronus_ai_model_id, {
        dtype: 'q8'
      });
      classifierState = 'ready';
      return classifierPipeline;
    } catch (err) {
      // Sem internet, CDN bloqueado, política de CSP do navegador, etc.
      // Não travamos a extensão: seguimos apenas com o pré-filtro (modo
      // degradado) e registramos o motivo no console para depuração.
      console.warn('[PatronusNet IA] Classificador indisponível, usando modo pré-filtro apenas:', err);
      classifierState = 'unavailable';
      classifierPipeline = null;
      return null;
    }
  }

  // Rótulos considerados "risco" pelos modelos de toxicidade mais comuns.
  const RISK_LABELS = new Set([
    'toxic', 'severe_toxic', 'obscene', 'threat', 'insult', 'identity_hate',
    'hate', 'hateful', 'offensive', 'LABEL_1'
  ]);

  async function classify(text) {
    const model = await ensureClassifier();
    if (!model) {
      // Modo degradado: já passou no pré-filtro léxico, então tratamos
      // como confiança moderada — suficiente para o usuário revisar, mas
      // deixamos o limiar mais conservador para reduzir falsos positivos.
      return { label: 'prefilter_match', score: 0.6, degraded: true };
    }
    try {
      const result = await model(text.slice(0, 512));
      // result pode vir como array de {label, score} ou array de arrays
      const flat = Array.isArray(result[0]) ? result[0] : result;
      let best = flat[0];
      for (const r of flat) if (r.score > best.score) best = r;
      const isRisk = RISK_LABELS.has(best.label) || /toxic|hate|threat|insult/i.test(best.label);
      return { label: best.label, score: isRisk ? best.score : 1 - best.score, degraded: false };
    } catch (err) {
      console.warn('[PatronusNet IA] Falha ao classificar trecho:', err);
      return { label: 'error', score: 0, degraded: true };
    }
  }

  // ── Ocultar elemento + registrar no histórico ────────────────────────────
  function hideElement(el, info) {
    if (processed.has(el)) return;
    processed.add(el);

    el.dataset.pnAiHidden = 'true';
    el.style.setProperty('display', 'none', 'important');

    const placeholder = document.createElement('div');
    placeholder.className = 'pn-ai-placeholder';
    placeholder.innerHTML = `
      <span class="pn-ai-ico">🤖🛡️</span>
      <span class="pn-ai-txt">Conteúdo ocultado pela IA do PatronusNet (possível discurso de ódio)</span>
      <button type="button" class="pn-ai-show">Mostrar mesmo assim</button>
    `;
    placeholder.querySelector('.pn-ai-show').addEventListener('click', () => {
      placeholder.remove();
      el.style.removeProperty('display');
      delete el.dataset.pnAiHidden;
    });
    el.insertAdjacentElement('afterend', placeholder);

    injectPlaceholderStyleOnce();

    chrome.runtime.sendMessage({
      type: 'LOG_BLOCK',
      url: location.href,
      reason: 'ai',
      matched: `${info.label} (${Math.round(info.score * 100)}%)`,
      title: document.title
    });
  }

  let styleInjected = false;
  function injectPlaceholderStyleOnce() {
    if (styleInjected) return;
    styleInjected = true;
    const style = document.createElement('style');
    style.textContent = `
      .pn-ai-placeholder{display:flex!important;align-items:center!important;gap:8px!important;
        background:rgba(249,115,22,.10)!important;border:1px solid rgba(249,115,22,.35)!important;
        border-radius:10px!important;padding:8px 12px!important;margin:6px 0!important;
        font-family:'Segoe UI',system-ui,sans-serif!important;font-size:12.5px!important;
        color:#c2410c!important;}
      .pn-ai-ico{font-size:15px!important;flex-shrink:0!important;}
      .pn-ai-txt{flex:1!important;}
      .pn-ai-show{background:transparent!important;border:1px solid rgba(249,115,22,.5)!important;
        color:#c2410c!important;border-radius:6px!important;padding:3px 9px!important;
        font-size:11.5px!important;cursor:pointer!important;flex-shrink:0!important;}
      .pn-ai-show:hover{background:rgba(249,115,22,.15)!important;}
    `;
    document.head.appendChild(style);
  }

  // ── Varredura principal ──────────────────────────────────────────────────
  let scanInFlight = false;
  async function scan() {
    if (scanInFlight) return;
    if (!cfg.patronus_ai_enabled) return;

    const isNewsHeuristic = cfg.patronus_ai_match_news_heuristic && looksLikeNewsArticle();
    if (!isTargetDomain(cfg.patronus_ai_domains) && !isNewsHeuristic) return;

    scanInFlight = true;
    try {
      const candidates = collectCandidateElements(cfg.patronus_ai_max_elements_per_scan);
      if (candidates.length === 0) return;

      // 2) Pré-filtro por termos-gatilho — descarta o que claramente não
      // precisa de classificação semântica (economiza CPU/bateria).
      const toClassify = [];
      for (const el of candidates) {
        const text = (el.innerText || el.textContent || '').trim();
        if (!text) { processed.add(el); continue; }
        if (passesPrefilter(text, cfg.patronus_ai_prefilter_terms)) {
          toClassify.push([el, text]);
        } else {
          processed.add(el); // já avaliado, não passou no pré-filtro
        }
      }
      if (toClassify.length === 0) return;

      // 3) Classificação semântica local (uma de cada vez, sem travar a UI)
      for (const [el, text] of toClassify) {
        const info = await classify(text);
        // 4) Decisão de bloqueio contextual
        if (info.score > cfg.patronus_ai_threshold) {
          hideElement(el, info);
        } else {
          processed.add(el);
        }
        // pequena pausa entre itens para não travar a thread principal
        await new Promise(r => setTimeout(r, 20));
      }
    } finally {
      scanInFlight = false;
    }
  }

  // ── Carrega config e observa mudanças ────────────────────────────────────
  function loadConfigAndRun() {
    const keys = Object.keys(DEFAULTS);
    chrome.storage.local.get(keys, (data) => {
      cfg = { ...DEFAULTS };
      for (const k of keys) {
        if (data[k] !== undefined) cfg[k] = data[k];
      }
      scan();
    });
  }

  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (Object.keys(DEFAULTS).some(k => changes[k])) loadConfigAndRun();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadConfigAndRun);
  } else {
    loadConfigAndRun();
  }

  // Re-varre em navegação SPA / conteúdo carregado dinamicamente
  // (Reddit e Quora renderizam via JS após o load inicial).
  let scanCooldown;
  const obs = new MutationObserver(() => {
    clearTimeout(scanCooldown);
    scanCooldown = setTimeout(scan, 1500);
  });
  if (document.body) obs.observe(document.body, { childList: true, subtree: true });

})();
