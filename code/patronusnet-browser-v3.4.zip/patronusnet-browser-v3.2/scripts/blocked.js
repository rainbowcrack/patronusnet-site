const reasonElement = document.getElementById('blocked-reason');
const urlElement = document.getElementById('blocked-url');
const unlockArea = document.getElementById('unlock-area');
const passwordLabel = document.getElementById('password-label');
const passwordInput = document.getElementById('parent-password');
const unlockButton = document.getElementById('unlock-button');
const unlockHelp = document.getElementById('unlock-help');
const unlockError = document.getElementById('unlock-error');
let hasPassword = false;
let blockContext = null;

function showError(message) {
  unlockError.textContent = message;
  unlockError.hidden = false;
}

function requestUnlock() {
  unlockError.hidden = true;
  unlockButton.disabled = true;
  chrome.runtime.sendMessage({
    type: 'UNLOCK_BLOCKED_PAGE',
    password: hasPassword ? passwordInput.value : ''
  }, response => {
    if (chrome.runtime.lastError || !response?.ok) {
      unlockButton.disabled = false;
      passwordInput.value = '';
      const retry = response?.retryAfter;
      showError(retry
        ? `Muitas tentativas. Aguarde ${retry} segundos.`
        : 'Senha incorreta.');
      if (hasPassword) passwordInput.focus();
    }
  });
}

function loadBlockContext(attempt = 0) {
  chrome.runtime.sendMessage({ type: 'GET_BLOCK_CONTEXT' }, response => {
    blockContext = response?.context || null;
    hasPassword = response?.hasPassword === true;
    if (!blockContext) {
      if (attempt < 5) {
        setTimeout(() => loadBlockContext(attempt + 1), 100);
        return;
      }
      reasonElement.textContent = 'Não foi possível recuperar os detalhes do bloqueio.';
      return;
    }

    const reasonName = blockContext.reason === 'domain' ? 'Domínio bloqueado' : 'Conteúdo detectado';
    reasonElement.textContent = blockContext.matched
      ? `${reasonName}: ${blockContext.matched}`
      : reasonName;
    urlElement.textContent = blockContext.url;
    unlockArea.hidden = false;
    unlockHelp.textContent = `A liberação vale somente nesta aba por ${response.unlockMinutes} minutos.`;

    if (!hasPassword) {
      passwordLabel.hidden = true;
      passwordInput.hidden = true;
      unlockButton.textContent = 'Continuar temporariamente';
      unlockHelp.textContent += ' Configure uma senha parental para impedir liberações sem autorização.';
    } else {
      passwordInput.focus();
    }

    chrome.runtime.sendMessage({
      type: 'LOG_BLOCK',
      url: blockContext.url,
      reason: blockContext.reason,
      matched: blockContext.matched,
      title: blockContext.title
    });
  });
}

loadBlockContext();

unlockButton.addEventListener('click', requestUnlock);
passwordInput.addEventListener('keydown', event => {
  if (event.key === 'Enter') requestUnlock();
});
document.getElementById('back-button').addEventListener('click', () => history.back());
