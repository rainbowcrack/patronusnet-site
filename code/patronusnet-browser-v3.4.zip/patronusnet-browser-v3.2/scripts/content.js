// PatronusNet v3.4 - Content Script

(function () {
  if (window.__patronusRunning) return;
  window.__patronusRunning = true;

  let redirecting = false;

  function normalizeForMatch(value) {
    return String(value || '')
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
  }

  function getPageText() {
    let text = `${document.title} `;
    const metas = document.querySelectorAll(
      'meta[name="keywords"],meta[name="description"],meta[property="og:description"]'
    );
    metas.forEach(meta => { text += ` ${meta.getAttribute('content') || ''}`; });
    if (document.body) text += ` ${document.body.innerText}`;
    return normalizeForMatch(text);
  }

  function containsTerm(text, term) {
    const normalizedTerm = normalizeForMatch(term).trim();
    if (!normalizedTerm) return false;
    const escaped = normalizedTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^\\p{L}\\p{N}_])${escaped}($|[^\\p{L}\\p{N}_])`, 'u').test(text);
  }

  function redirectToBlockPage(reason, matched, stealthMode) {
    if (redirecting) return;
    redirecting = true;
    if (stealthMode) {
      document.documentElement.style.display = 'none';
      chrome.runtime.sendMessage({
        type: 'STEALTH_BLOCK_CURRENT_PAGE',
        url: location.href,
        reason,
        matched,
        title: document.title
      }, () => location.replace('about:blank'));
      return;
    }
    chrome.runtime.sendMessage({
      type: 'BLOCK_CURRENT_PAGE',
      url: location.href,
      reason,
      matched,
      title: document.title
    });
  }

  function check() {
    if (redirecting) return;
    chrome.runtime.sendMessage({ type: 'CHECK_PAGE', url: location.href }, res => {
      if (chrome.runtime.lastError || !res?.enabled || !Array.isArray(res.tags) || res.tags.length === 0) return;

      const normalizedUrl = normalizeForMatch(location.href);
      const pageText = res.checkContent ? getPageText() : '';
      for (const entry of res.tags) {
        const tag = String(entry?.tag ?? entry ?? '').trim();
        if (!tag) continue;
        const inUrl = res.checkUrl && normalizeForMatch(normalizedUrl).includes(normalizeForMatch(tag));
        const inPage = res.checkContent && containsTerm(pageText, tag);
        if (inUrl || inPage) {
          redirectToBlockPage('tag', tag, res.stealthMode === true);
          return;
        }
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', check, { once: true });
  } else {
    check();
  }

  let spaCooldown;
  const observer = new MutationObserver(() => {
    clearTimeout(spaCooldown);
    spaCooldown = setTimeout(check, 1200);
  });
  if (document.body) observer.observe(document.body, { childList: true, subtree: true });
})();
