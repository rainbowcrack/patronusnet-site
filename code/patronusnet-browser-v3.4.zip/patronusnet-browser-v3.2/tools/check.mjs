import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const dist = join(root, 'dist');
const manifest = JSON.parse(await readFile(join(dist, 'manifest.json'), 'utf8'));
const bundle = await readFile(join(dist, 'scripts', 'ai_classifier.bundle.js'), 'utf8');
const wasmFiles = (await readdir(join(dist, 'vendor', 'ort'))).filter(name => name.endsWith('.wasm'));
const packagedScripts = await readdir(join(dist, 'scripts'));
const requiredFiles = [
  manifest.background?.service_worker,
  manifest.action?.default_popup,
  manifest.options_page,
  'blocked.html',
  ...manifest.content_scripts.flatMap(entry => [...(entry.js || []), ...(entry.css || [])])
].filter(Boolean);

if (manifest.manifest_version !== 3) throw new Error('O manifesto não é MV3.');
if (!manifest.permissions?.includes('declarativeNetRequest')) throw new Error('Permissão DNR ausente.');
if (/https:\/\/cdn\.jsdelivr\.net\/npm\/@(?:xenova|huggingface)\/transformers/i.test(bundle)) {
  throw new Error('O bundle ainda contém importação remota do Transformers.js.');
}
if (wasmFiles.length === 0) throw new Error('Arquivos WASM locais ausentes.');
if (packagedScripts.includes('ai_classifier.js')) throw new Error('O código-fonte não empacotado entrou em dist/.');
for (const relativePath of requiredFiles) {
  await readFile(join(dist, relativePath.replace(/^\.\//, '')));
}

console.log(`Validação básica concluída em dist/: MV3, DNR, bundle local e ${wasmFiles.length} WASM.`);
