import { build } from 'esbuild';
import { copyFile, cp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const wasmSource = join(root, 'node_modules', 'onnxruntime-web', 'dist');
const wasmTarget = join(root, 'vendor', 'ort');
const dist = join(root, 'dist');

await build({
  entryPoints: [join(root, 'scripts', 'ai_classifier.js')],
  outfile: join(root, 'scripts', 'ai_classifier.bundle.js'),
  bundle: true,
  format: 'iife',
  platform: 'browser',
  target: ['chrome120'],
  minify: true,
  sourcemap: false,
  legalComments: 'none',
  define: {
    'process.env.NODE_ENV': '"production"'
  }
});

// O pacote mantém um fallback textual para um CDN mesmo quando wasmPaths é
// configurado localmente. Removemos esse fallback do artefato MV3 para que não
// exista qualquer caminho capaz de buscar código/WASM executável remotamente.
const bundlePath = join(root, 'scripts', 'ai_classifier.bundle.js');
const bundledSource = await readFile(bundlePath, 'utf8');
await writeFile(
  bundlePath,
  bundledSource.replaceAll(
    'https://cdn.jsdelivr.net/npm/@huggingface/transformers@',
    '/vendor/transformers/'
  ),
  'utf8'
);

await mkdir(wasmTarget, { recursive: true });
const wasmFiles = (await readdir(wasmSource)).filter(name => name.endsWith('.wasm'));
if (wasmFiles.length === 0) {
  throw new Error('Nenhum binário WASM do ONNX Runtime foi encontrado.');
}

await Promise.all(wasmFiles.map(name =>
  copyFile(join(wasmSource, name), join(wasmTarget, name))
));

await rm(dist, { recursive: true, force: true });
await mkdir(join(dist, 'scripts'), { recursive: true });
await Promise.all([
  copyFile(join(root, 'manifest.json'), join(dist, 'manifest.json')),
  copyFile(join(root, 'options.html'), join(dist, 'options.html')),
  copyFile(join(root, 'popup.html'), join(dist, 'popup.html')),
  copyFile(join(root, 'blocked.html'), join(dist, 'blocked.html')),
  copyFile(join(root, 'THIRD_PARTY_NOTICES.md'), join(dist, 'THIRD_PARTY_NOTICES.md')),
  cp(join(root, 'icons'), join(dist, 'icons'), { recursive: true }),
  cp(join(root, 'styles'), join(dist, 'styles'), { recursive: true }),
  cp(join(root, 'vendor'), join(dist, 'vendor'), { recursive: true })
]);

await mkdir(join(dist, 'licenses'), { recursive: true });
await copyFile(
  join(root, 'node_modules', '@huggingface', 'transformers', 'LICENSE'),
  join(dist, 'licenses', 'TRANSFORMERS_JS_APACHE_2.0.txt')
);

const scriptFiles = (await readdir(join(root, 'scripts')))
  .filter(name => name.endsWith('.js') && name !== 'ai_classifier.js');
await Promise.all(scriptFiles.map(name =>
  copyFile(join(root, 'scripts', name), join(dist, 'scripts', name))
));

console.log(`Build concluído em dist/: bundle local e ${wasmFiles.length} arquivos WASM.`);
