// PatronusNet v3 - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get(
    ['patronus_domains', 'patronus_tags', 'patronus_enabled', 'patronus_log'],
    (d) => {
      const enabled = d.patronus_enabled !== false;
      const log = d.patronus_log || [];

      const tog = document.getElementById('tog');
      tog.checked = enabled;

      const dot = document.getElementById('statusDot');
      dot.className = 'status-dot' + (enabled ? '' : ' off');

      document.getElementById('dn').textContent = (d.patronus_domains || []).length;
      document.getElementById('tn').textContent = (d.patronus_tags || []).length;
      document.getElementById('bn').textContent = log.length;

      const today = new Date().toDateString();
      const todayBlocks = log.filter(e => new Date(e.timestamp).toDateString() === today);
      document.getElementById('todayCount').textContent = todayBlocks.length;
      const pct = Math.min(100, (todayBlocks.length / 10) * 100);
      document.getElementById('todayBar').style.width = pct + '%';

      const lastContent = document.getElementById('lastBlockContent');
      if (log.length > 0) {
        const last = log[0];
        const ago = timeAgo(new Date(last.timestamp));
        const icon = last.reason === 'domain' ? '🌐' : '🔍';
        lastContent.innerHTML = `
          <div class="lb-item">
            <span class="lb-icon">${icon}</span>
            <span class="lb-text">${last.matched || last.url}</span>
            <span class="lb-time">${ago}</span>
          </div>`;
      }
    }
  );

  // ── Toggle + Modal de senha ───────────────────────────────────────────────

  const tog_status = document.getElementById('tog');

  // Estado que o usuário QUER atingir (capturado no click, antes de qualquer reversão)
  let estadoDesejado = false;

  function abrirModal() {
    const input = document.getElementById('passwordInput');
    input.value = '';
    input.placeholder = 'Digite a senha';
    input.style.borderColor = '';
    document.getElementById('passwordModal').style.display = 'flex';
    input.focus();
  }

  function fecharModal() {
    document.getElementById('passwordModal').style.display = 'none';
    document.getElementById('passwordInput').value = '';
  }

  function aplicarEstado(estado) {
    tog_status.checked = estado;
    chrome.storage.local.set({ patronus_enabled: estado });
    document.getElementById('statusDot').className =
      'status-dot' + (estado ? '' : ' off');
  }

  document.getElementById('cancelPassword').addEventListener('click', () => {
    fecharModal();
    // Reverte o visual para o estado anterior (oposto do que o usuário queria)
    tog_status.checked = !estadoDesejado;
  });

  document.getElementById('confirmPassword').addEventListener('click', async function () {
    const senha = document.getElementById('passwordInput').value;
    const ok = await verificarSenha(senha);
    if (ok) {
      fecharModal();
      aplicarEstado(estadoDesejado);
    } else {
      const input = document.getElementById('passwordInput');
      input.value = '';
      input.placeholder = 'Senha incorreta!';
      input.style.borderColor = '#f87171';
    }
  });

  document.getElementById('passwordInput').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') document.getElementById('confirmPassword').click();
  });

  tog_status.addEventListener('click', function () {
    // No Chrome, e.preventDefault() NÃO funciona em checkbox —
    // o .checked já reflete o NOVO estado quando o click dispara.
    // Capturamos esse novo estado como "desejado".
    estadoDesejado = tog_status.checked;

    chrome.storage.local.get(['patronus_auth'], function (data) {
      if (!data.patronus_auth) {
        // Sem senha: aceita a mudança diretamente
        aplicarEstado(estadoDesejado);
        return;
      }
      // Com senha: reverte o visual e pede autenticação
      tog_status.checked = !estadoDesejado;
      abrirModal();
    });
  });

  // ── Navegação ─────────────────────────────────────────────────────────────

  document.getElementById('cfg').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
    window.close();
  });

  document.getElementById('router').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') + '#router' });
    window.close();
  });

  document.getElementById('viewLog').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html') + '#log' });
    window.close();
  });
});

function timeAgo(date) {
  const diff = Math.floor((Date.now() - date) / 1000);
  if (diff < 60) return 'agora';
  if (diff < 3600) return Math.floor(diff / 60) + 'min atrás';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h atrás';
  return Math.floor(diff / 86400) + 'd atrás';
}
