async function hashPassword(password) {

    const encoder = new TextEncoder();
    const data = encoder.encode(password);

    const hash = await crypto.subtle.digest("SHA-256", data);

    return Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
}

async function verificarSenha(senha) {

    return new Promise(async (resolve) => {

        chrome.storage.local.get(
            ["patronus_auth"],
            async (data) => {

                const senhaSalva = data.patronus_auth || "";

                if (!senhaSalva) {
                    resolve(true);
                    return;
                }

                const hash = await hashPassword(senha);

                resolve(hash === senhaSalva);

            }
        );

    });

}