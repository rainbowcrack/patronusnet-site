# Componentes de terceiros

O pacote distribuído da PatronusNet incorpora os seguintes componentes:

- **Transformers.js 3.8.1**, Hugging Face, licença Apache-2.0.
  <https://github.com/huggingface/transformers.js>
- **ONNX Runtime Web 1.21.0**, Microsoft, licença MIT.
  <https://github.com/microsoft/onnxruntime>

O modelo padrão `onnx-community/distilbert-multilingual-toxicity-classifier-ONNX` não é
incorporado ao pacote. Seus arquivos são obtidos como dados na primeira utilização e
armazenados no cache do navegador. O modelo é disponibilizado sob OpenRAIL++; consulte
<https://huggingface.co/onnx-community/distilbert-multilingual-toxicity-classifier-ONNX>
antes de qualquer distribuição que passe a incorporar os pesos diretamente.
